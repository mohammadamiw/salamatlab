<?php

/**
 * کلاس مسیریابی
 * Router Class
 * 
 * مدیریت مسیرها و اجرای کنترلرها
 */

class Router
{
    private static $routes = [
        'GET' => [],
        'POST' => [],
        'PUT' => [],
        'DELETE' => [],
        'PATCH' => []
    ];
    
    private static $middlewares = [];
    private static $prefix = '';
    private static $currentMiddleware = [];
    
    /**
     * تعریف مسیر GET
     */
    public static function get(string $path, $handler): void
    {
        self::addRoute('GET', $path, $handler);
    }
    
    /**
     * تعریف مسیر POST
     */
    public static function post(string $path, $handler): void
    {
        self::addRoute('POST', $path, $handler);
    }
    
    /**
     * تعریف مسیر PUT
     */
    public static function put(string $path, $handler): void
    {
        self::addRoute('PUT', $path, $handler);
    }
    
    /**
     * تعریف مسیر DELETE
     */
    public static function delete(string $path, $handler): void
    {
        self::addRoute('DELETE', $path, $handler);
    }
    
    /**
     * تعریف مسیر PATCH
     */
    public static function patch(string $path, $handler): void
    {
        self::addRoute('PATCH', $path, $handler);
    }
    
    /**
     * گروه‌بندی مسیرها با prefix
     */
    public static function group(array $attributes, callable $callback): void
    {
        $oldPrefix = self::$prefix;
        $oldMiddleware = self::$currentMiddleware;
        
        // تنظیم prefix جدید
        if (isset($attributes['prefix'])) {
            self::$prefix = $oldPrefix . '/' . trim($attributes['prefix'], '/');
        }
        
        // تنظیم middleware جدید
        if (isset($attributes['middleware'])) {
            self::$currentMiddleware = array_merge(
                self::$currentMiddleware, 
                is_array($attributes['middleware']) ? $attributes['middleware'] : [$attributes['middleware']]
            );
        }
        
        // اجرای callback
        $callback();
        
        // بازگرداندن تنظیمات قبلی
        self::$prefix = $oldPrefix;
        self::$currentMiddleware = $oldMiddleware;
    }
    
    /**
     * افزودن middleware
     */
    public static function middleware($middleware): self
    {
        if (is_string($middleware)) {
            self::$currentMiddleware[] = $middleware;
        } elseif (is_array($middleware)) {
            self::$currentMiddleware = array_merge(self::$currentMiddleware, $middleware);
        }
        
        return new self();
    }
    
    /**
     * اضافه کردن مسیر
     */
    private static function addRoute(string $method, string $path, $handler): void
    {
        $fullPath = self::$prefix . '/' . trim($path, '/');
        $fullPath = '/' . trim($fullPath, '/');
        
        // تبدیل پارامترها به regex
        $pattern = preg_replace('/\{([^}]+)\}/', '([^/]+)', $fullPath);
        $pattern = '#^' . $pattern . '$#';
        
        self::$routes[$method][] = [
            'pattern' => $pattern,
            'path' => $fullPath,
            'handler' => $handler,
            'middleware' => self::$currentMiddleware
        ];
    }
    
    /**
     * اجرای مسیریاب
     */
    public static function dispatch(): void
    {
        $requestMethod = $_SERVER['REQUEST_METHOD'];
        $requestUri = $_SERVER['REQUEST_URI'];
        
        // حذف query string
        $requestUri = strtok($requestUri, '?');
        
        // حذف trailing slash
        $requestUri = rtrim($requestUri, '/');
        if (empty($requestUri)) {
            $requestUri = '/';
        }
        
        // پیدا کردن مسیر مناسب
        $route = self::findRoute($requestMethod, $requestUri);
        
        if ($route) {
            try {
                // اجرای middleware ها
                self::runMiddlewares($route['middleware']);
                
                // اجرای handler
                self::runHandler($route['handler'], $route['params'] ?? []);
                
            } catch (Exception $e) {
                self::handleException($e);
            }
        } else {
            self::notFound();
        }
    }
    
    /**
     * پیدا کردن مسیر
     */
    private static function findRoute(string $method, string $uri): ?array
    {
        if (!isset(self::$routes[$method])) {
            return null;
        }
        
        foreach (self::$routes[$method] as $route) {
            if (preg_match($route['pattern'], $uri, $matches)) {
                array_shift($matches); // حذف کل match
                
                return [
                    'handler' => $route['handler'],
                    'middleware' => $route['middleware'],
                    'params' => $matches
                ];
            }
        }
        
        return null;
    }
    
    /**
     * اجرای middleware ها
     */
    private static function runMiddlewares(array $middlewares): void
    {
        foreach ($middlewares as $middleware) {
            if (is_string($middleware)) {
                $middlewareClass = $middleware . 'Middleware';
                
                if (!class_exists($middlewareClass)) {
                    throw new Exception("Middleware {$middlewareClass} not found");
                }
                
                $instance = new $middlewareClass();
                $instance->handle();
            }
        }
    }
    
    /**
     * اجرای handler
     */
    private static function runHandler($handler, array $params = []): void
    {
        if (is_string($handler) && strpos($handler, '@') !== false) {
            // Controller@method format
            [$controllerName, $methodName] = explode('@', $handler);
            
            if (!class_exists($controllerName)) {
                throw new Exception("Controller {$controllerName} not found");
            }
            
            $controller = new $controllerName();
            
            if (!method_exists($controller, $methodName)) {
                throw new Exception("Method {$methodName} not found in {$controllerName}");
            }
            
            call_user_func_array([$controller, $methodName], $params);
            
        } elseif (is_callable($handler)) {
            // Anonymous function
            call_user_func_array($handler, $params);
            
        } else {
            throw new Exception("Invalid handler type");
        }
    }
    
    /**
     * مدیریت استثناء
     */
    private static function handleException(Exception $e): void
    {
        http_response_code(500);
        header('Content-Type: application/json; charset=UTF-8');
        
        $response = [
            'success' => false,
            'message' => 'خطای داخلی سرور'
        ];
        
        // در حالت debug، جزئیات خطا را نمایش بده
        $config = require __DIR__ . '/../config/app.php';
        if ($config['debug']) {
            $response['error'] = $e->getMessage();
            $response['file'] = $e->getFile();
            $response['line'] = $e->getLine();
            $response['trace'] = $e->getTraceAsString();
        }
        
        // لاگ خطا
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ];
        
        $logLine = json_encode($logData, JSON_UNESCAPED_UNICODE) . "\n";
        $logFile = __DIR__ . '/../storage/logs/error-' . date('Y-m-d') . '.log';
        
        // اطمینان از وجود پوشه logs
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * صفحه پیدا نشد
     */
    private static function notFound(): void
    {
        http_response_code(404);
        header('Content-Type: application/json; charset=UTF-8');
        
        echo json_encode([
            'success' => false,
            'message' => 'مسیر پیدا نشد'
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        
        exit;
    }
    
    /**
     * دریافت تمام مسیرها
     */
    public static function getRoutes(): array
    {
        return self::$routes;
    }
    
    /**
     * پاک کردن تمام مسیرها
     */
    public static function clearRoutes(): void
    {
        self::$routes = [
            'GET' => [],
            'POST' => [],
            'PUT' => [],
            'DELETE' => [],
            'PATCH' => []
        ];
    }
}
