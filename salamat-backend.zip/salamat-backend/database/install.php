<?php

/**
 * اسکریپت نصب پایگاه داده
 * Database Installation Script
 * 
 * SalamatLab v2.0
 */

require_once __DIR__ . '/Database.php';

echo "🚀 شروع نصب پایگاه داده سامانه سلامت‌لاب...\n\n";

try {
    // اتصال به پایگاه داده
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    echo "✅ اتصال به پایگاه داده برقرار شد\n";
    
    // لیست فایل‌های migration
    $migrationFiles = [
        '001_create_users_table.sql',
        '002_create_otp_codes_table.sql',
        '003_create_doctors_table.sql',
        '004_create_medical_services_table.sql',
        '005_create_checkup_requests_table.sql',
        '006_create_home_sampling_requests_table.sql',
        '007_create_blog_posts_table.sql',
        '008_create_contact_messages_table.sql',
        '009_create_feedback_surveys_table.sql'
    ];
    
    // اجرای migration ها
    foreach ($migrationFiles as $file) {
        $filePath = __DIR__ . '/migrations/' . $file;
        
        if (file_exists($filePath)) {
            echo "📄 اجرای migration: {$file}\n";
            
            $sql = file_get_contents($filePath);
            $pdo->exec($sql);
            
            echo "✅ {$file} با موفقیت اجرا شد\n";
        } else {
            echo "❌ فایل {$file} یافت نشد\n";
        }
    }
    
    // درج داده‌های نمونه
    echo "\n🌱 درج داده‌های نمونه...\n";
    
    // درج پزشکان نمونه
    $doctors = [
        [
            'name' => 'دکتر احمد محمدی',
            'specialty' => 'قلب و عروق',
            'education' => 'فوق تخصص قلب و عروق - دانشگاه تهران',
            'experience_years' => 15,
            'description' => 'متخصص قلب و عروق با 15 سال سابقه کار',
            'phone' => '09123456789',
            'email' => 'ahmad.mohammadi@example.com',
            'consultation_fee' => 500000,
            'rating' => 4.8,
            'review_count' => 120
        ],
        [
            'name' => 'دکتر فاطمه احمدی',
            'specialty' => 'زنان و زایمان',
            'education' => 'فوق تخصص زنان و زایمان - دانشگاه شهید بهشتی',
            'experience_years' => 12,
            'description' => 'متخصص زنان و زایمان با 12 سال سابقه کار',
            'phone' => '09123456790',
            'email' => 'fateme.ahmadi@example.com',
            'consultation_fee' => 450000,
            'rating' => 4.9,
            'review_count' => 95
        ],
        [
            'name' => 'دکتر علی رضایی',
            'specialty' => 'اطفال',
            'education' => 'فوق تخصص اطفال - دانشگاه علوم پزشکی تهران',
            'experience_years' => 18,
            'description' => 'متخصص اطفال با 18 سال سابقه کار',
            'phone' => '09123456791',
            'email' => 'ali.rezaei@example.com',
            'consultation_fee' => 400000,
            'rating' => 4.7,
            'review_count' => 150
        ]
    ];
    
    $stmt = $pdo->prepare("
        INSERT INTO doctors (name, specialty, education, experience_years, description, phone, email, consultation_fee, rating, review_count) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($doctors as $doctor) {
        $stmt->execute([
            $doctor['name'],
            $doctor['specialty'],
            $doctor['education'],
            $doctor['experience_years'],
            $doctor['description'],
            $doctor['phone'],
            $doctor['email'],
            $doctor['consultation_fee'],
            $doctor['rating'],
            $doctor['review_count']
        ]);
    }
    
    echo "✅ پزشکان نمونه درج شدند\n";
    
    // درج خدمات پزشکی نمونه
    $services = [
        [
            'name' => 'آزمایش خون کامل',
            'category' => 'آزمایشات',
            'description' => 'آزمایش کامل خون شامل CBC، قند، چربی و...',
            'price' => 150000,
            'duration_minutes' => 30,
            'requirements' => 'ناشتا بودن 12 ساعت',
            'preparation_instructions' => 'از شب قبل ناشتا باشید'
        ],
        [
            'name' => 'سونوگرافی شکم',
            'category' => 'تصویربرداری',
            'description' => 'سونوگرافی کامل شکم و لگن',
            'price' => 200000,
            'duration_minutes' => 45,
            'requirements' => 'مثانه پر',
            'preparation_instructions' => '2 ساعت قبل آب بنوشید'
        ],
        [
            'name' => 'نوار قلب',
            'category' => 'تست‌های قلبی',
            'description' => 'الکتروکاردیوگرام (ECG)',
            'price' => 80000,
            'duration_minutes' => 15,
            'requirements' => 'بدون نیاز به آمادگی خاص',
            'preparation_instructions' => 'بدون نیاز به آمادگی خاص'
        ]
    ];
    
    $stmt = $pdo->prepare("
        INSERT INTO medical_services (name, category, description, price, duration_minutes, requirements, preparation_instructions) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($services as $service) {
        $stmt->execute([
            $service['name'],
            $service['category'],
            $service['description'],
            $service['price'],
            $service['duration_minutes'],
            $service['requirements'],
            $service['preparation_instructions']
        ]);
    }
    
    echo "✅ خدمات پزشکی نمونه درج شدند\n";
    
    // درج مقالات بلاگ نمونه
    $blogPosts = [
        [
            'title' => 'راهنمای کامل آزمایش خون',
            'slug' => 'complete-blood-test-guide',
            'content' => 'آزمایش خون یکی از مهم‌ترین روش‌های تشخیصی در پزشکی است...',
            'excerpt' => 'راهنمای کامل برای درک نتایج آزمایش خون',
            'category' => 'آزمایشات',
            'tags' => 'آزمایش خون, تشخیص, پزشکی',
            'author_name' => 'دکتر احمد محمدی',
            'author_email' => 'ahmad.mohammadi@example.com',
            'status' => 'published',
            'published_at' => date('Y-m-d H:i:s')
        ],
        [
            'title' => 'نکات مهم قبل از سونوگرافی',
            'slug' => 'ultrasound-preparation-tips',
            'content' => 'سونوگرافی یکی از روش‌های تصویربرداری بی‌خطر است...',
            'excerpt' => 'نکات مهم برای آمادگی قبل از سونوگرافی',
            'category' => 'تصویربرداری',
            'tags' => 'سونوگرافی, تصویربرداری, آمادگی',
            'author_name' => 'دکتر فاطمه احمدی',
            'author_email' => 'fateme.ahmadi@example.com',
            'status' => 'published',
            'published_at' => date('Y-m-d H:i:s')
        ]
    ];
    
    $stmt = $pdo->prepare("
        INSERT INTO blog_posts (title, slug, content, excerpt, category, tags, author_name, author_email, status, published_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($blogPosts as $post) {
        $stmt->execute([
            $post['title'],
            $post['slug'],
            $post['content'],
            $post['excerpt'],
            $post['category'],
            $post['tags'],
            $post['author_name'],
            $post['author_email'],
            $post['status'],
            $post['published_at']
        ]);
    }
    
    echo "✅ مقالات بلاگ نمونه درج شدند\n";
    
    echo "\n🎉 نصب پایگاه داده با موفقیت تکمیل شد!\n";
    echo "📊 آمار نصب:\n";
    echo "   - 3 پزشک نمونه\n";
    echo "   - 3 خدمت پزشکی نمونه\n";
    echo "   - 2 مقاله بلاگ نمونه\n";
    echo "   - 9 جدول پایگاه داده\n\n";
    
    echo "🔗 برای شروع کار:\n";
    echo "   1. فایل .env را کپی کنید و تنظیمات را انجام دهید\n";
    echo "   2. سرور PHP را راه‌اندازی کنید\n";
    echo "   3. API را در آدرس http://localhost:8000/api/health تست کنید\n\n";
    
} catch (Exception $e) {
    echo "❌ خطا در نصب پایگاه داده: " . $e->getMessage() . "\n";
    echo "📁 فایل: " . $e->getFile() . "\n";
    echo "📍 خط: " . $e->getLine() . "\n";
    exit(1);
}
