<?php

/**
 * کلاس اتصال به پایگاه داده
 * Database Connection Class
 * 
 * مدیریت اتصالات PDO با پشتیبانی از Connection Pool
 */

class Database
{
    private static $instance = null;
    private $connections = [];
    private $config;
    
    private function __construct()
    {
        $this->config = require __DIR__ . '/../config/database.php';
    }
    
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * دریافت اتصال پایگاه داده
     */
    public function getConnection(string $name = 'default'): PDO
    {
        if (!isset($this->connections[$name])) {
            $this->connections[$name] = $this->createConnection($name);
        }
        
        return $this->connections[$name];
    }
    
    /**
     * ایجاد اتصال جدید
     */
    private function createConnection(string $name): PDO
    {
        $config = $this->config[$name] ?? $this->config['default'];
        
        if (!$config) {
            throw new InvalidArgumentException("Database configuration '{$name}' not found.");
        }
        
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $config['host'],
            $config['port'],
            $config['database'],
            $config['charset']
        );
        
        try {
            $pdo = new PDO(
                $dsn,
                $config['username'],
                $config['password'],
                $config['options'] ?? []
            );
            
            // تنظیمات اضافی
            $pdo->exec("SET time_zone = '+04:30'"); // تنظیم منطقه زمانی ایران
            $pdo->exec("SET sql_mode = 'STRICT_TRANS_TABLES'");
            
            return $pdo;
            
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new RuntimeException("خطا در اتصال به پایگاه داده: " . $e->getMessage());
        }
    }
    
    /**
     * اجرای Query با پشتیبانی از Prepared Statements
     */
    public function query(string $sql, array $params = [], string $connection = 'default'): PDOStatement
    {
        $pdo = $this->getConnection($connection);
        
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
            
        } catch (PDOException $e) {
            error_log("Query failed: " . $e->getMessage() . " SQL: " . $sql);
            throw new RuntimeException("خطا در اجرای دستور SQL: " . $e->getMessage());
        }
    }
    
    /**
     * دریافت یک رکورد
     */
    public function fetch(string $sql, array $params = [], string $connection = 'default'): ?array
    {
        $stmt = $this->query($sql, $params, $connection);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * دریافت همه رکوردها
     */
    public function fetchAll(string $sql, array $params = [], string $connection = 'default'): array
    {
        $stmt = $this->query($sql, $params, $connection);
        return $stmt->fetchAll();
    }
    
    /**
     * اجرای INSERT و برگرداندن ID
     */
    public function insert(string $table, array $data, string $connection = 'default'): string
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        
        $this->query($sql, $data, $connection);
        
        return $this->getConnection($connection)->lastInsertId();
    }
    
    /**
     * اجرای UPDATE
     */
    public function update(string $table, array $data, string $where, array $whereParams = [], string $connection = 'default'): int
    {
        $setParts = [];
        foreach (array_keys($data) as $key) {
            $setParts[] = "{$key} = :{$key}";
        }
        $setClause = implode(', ', $setParts);
        
        $sql = "UPDATE {$table} SET {$setClause} WHERE {$where}";
        
        $params = array_merge($data, $whereParams);
        $stmt = $this->query($sql, $params, $connection);
        
        return $stmt->rowCount();
    }
    
    /**
     * اجرای DELETE
     */
    public function delete(string $table, string $where, array $params = [], string $connection = 'default'): int
    {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        $stmt = $this->query($sql, $params, $connection);
        return $stmt->rowCount();
    }
    
    /**
     * شروع تراکنش
     */
    public function beginTransaction(string $connection = 'default'): void
    {
        $this->getConnection($connection)->beginTransaction();
    }
    
    /**
     * تأیید تراکنش
     */
    public function commit(string $connection = 'default'): void
    {
        $this->getConnection($connection)->commit();
    }
    
    /**
     * بازگردانی تراکنش
     */
    public function rollback(string $connection = 'default'): void
    {
        $this->getConnection($connection)->rollback();
    }
    
    /**
     * اجرای Migration
     */
    public function migrate(): void
    {
        $migrationPath = __DIR__ . '/migrations/';
        $migrationFiles = glob($migrationPath . '*.sql');
        
        if (empty($migrationFiles)) {
            echo "هیچ فایل migration یافت نشد.\n";
            return;
        }
        
        // ایجاد جدول migrations اگر وجود نداشته باشد
        $this->createMigrationsTable();
        
        foreach ($migrationFiles as $file) {
            $filename = basename($file);
            
            // بررسی اجرای قبلی
            $executed = $this->fetch(
                "SELECT id FROM migrations WHERE filename = ?", 
                [$filename]
            );
            
            if ($executed) {
                echo "Migration '{$filename}' قبلاً اجرا شده است.\n";
                continue;
            }
            
            try {
                $sql = file_get_contents($file);
                $this->getConnection()->exec($sql);
                
                // ثبت در جدول migrations
                $this->insert('migrations', [
                    'filename' => $filename,
                    'executed_at' => date('Y-m-d H:i:s')
                ]);
                
                echo "Migration '{$filename}' با موفقیت اجرا شد.\n";
                
            } catch (Exception $e) {
                echo "خطا در اجرای Migration '{$filename}': " . $e->getMessage() . "\n";
                break;
            }
        }
    }
    
    /**
     * ایجاد جدول migrations
     */
    private function createMigrationsTable(): void
    {
        $sql = "CREATE TABLE IF NOT EXISTS migrations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            filename VARCHAR(255) NOT NULL UNIQUE,
            executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $this->getConnection()->exec($sql);
    }
    
    /**
     * بستن اتصالات
     */
    public function closeConnections(): void
    {
        $this->connections = [];
    }
    
    /**
     * جلوگیری از کلون کردن
     */
    private function __clone() {}
    
    /**
     * جلوگیری از unserialize
     */
    public function __wakeup()
    {
        throw new Exception("Cannot unserialize singleton");
    }
}
