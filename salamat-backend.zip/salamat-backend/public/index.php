<?php

/**
 * نقطه ورود اصلی API
 * Main API Entry Point
 * 
 * SalamatLab API v2.0
 * PHP Version: 8.2+
 */

// تنظیمات خطا
error_reporting(E_ALL);
ini_set('display_errors', 0);

// تنظیمات UTF-8
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');

// تنظیمات timezone
date_default_timezone_set('Asia/Tehran');

// تنظیمات CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Max-Age: 86400');

// مدیریت OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// تنظیم Content-Type
header('Content-Type: application/json; charset=UTF-8');

try {
    // بارگذاری autoloader
    require_once __DIR__ . '/../vendor/autoload.php';
    
    // بارگذاری متغیرهای محیطی
    if (file_exists(__DIR__ . '/../.env')) {
        $lines = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
                [$key, $value] = explode('=', $line, 2);
                $_ENV[trim($key)] = trim($value);
            }
        }
    }
    
    // بارگذاری کلاس‌های اصلی
    require_once __DIR__ . '/../database/Database.php';
    require_once __DIR__ . '/../app/Models/BaseModel.php';
    require_once __DIR__ . '/../app/Controllers/BaseController.php';
    require_once __DIR__ . '/../app/Middleware/CORSMiddleware.php';
    require_once __DIR__ . '/../app/Middleware/AuthMiddleware.php';
    require_once __DIR__ . '/../app/Middleware/RateLimitMiddleware.php';
    require_once __DIR__ . '/../routes/Router.php';
    
    // بارگذاری مدل‌ها
    require_once __DIR__ . '/../app/Models/User.php';
    require_once __DIR__ . '/../app/Models/Doctor.php';
    require_once __DIR__ . '/../app/Models/MedicalService.php';
    require_once __DIR__ . '/../app/Models/CheckupRequest.php';
    require_once __DIR__ . '/../app/Models/HomeSamplingRequest.php';
    require_once __DIR__ . '/../app/Models/BlogPost.php';
    require_once __DIR__ . '/../app/Models/ContactMessage.php';
    require_once __DIR__ . '/../app/Models/FeedbackSurvey.php';
    
    // بارگذاری سرویس‌ها
    require_once __DIR__ . '/../app/Services/OTPService.php';
    require_once __DIR__ . '/../app/Services/SMSService.php';
    
    // بارگذاری کنترلرها
    require_once __DIR__ . '/../app/Controllers/AuthController.php';
    require_once __DIR__ . '/../app/Controllers/MedicalController.php';
    require_once __DIR__ . '/../app/Controllers/ContentController.php';
    
    // تعریف مسیرها
    defineRoutes();
    
    // اجرای مسیریاب
    Router::dispatch();
    
} catch (Exception $e) {
    // مدیریت خطاهای کلی
    http_response_code(500);
    
    $response = [
        'success' => false,
        'message' => 'خطای داخلی سرور'
    ];
    
    // در حالت debug، جزئیات خطا را نمایش بده
    $config = require __DIR__ . '/../config/app.php';
    if ($config['debug']) {
        $response['error'] = $e->getMessage();
        $response['file'] = $e->getFile();
        $response['line'] = $e->getLine();
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * تعریف مسیرهای API
 */
function defineRoutes()
{
    // مسیرهای احراز هویت
    Router::group(['prefix' => 'api/auth'], function() {
        Router::post('send-otp', 'App\Controllers\AuthController@sendOTP');
        Router::post('verify-otp', 'App\Controllers\AuthController@verifyOTP');
        Router::post('complete-profile', 'App\Controllers\AuthController@completeProfile')
            ->middleware(['auth']);
        Router::post('logout', 'App\Controllers\AuthController@logout')
            ->middleware(['auth']);
        Router::get('me', 'App\Controllers\AuthController@me')
            ->middleware(['auth']);
    });
    
    // مسیرهای پزشکی
    Router::group(['prefix' => 'api/medical'], function() {
        Router::get('doctors', 'App\Controllers\MedicalController@getDoctors');
        Router::get('doctors/{id}', 'App\Controllers\MedicalController@getDoctor');
        Router::get('specialties', 'App\Controllers\MedicalController@getSpecialties');
        Router::get('services', 'App\Controllers\MedicalController@getMedicalServices');
        Router::get('services/{id}', 'App\Controllers\MedicalController@getMedicalService');
        Router::get('service-categories', 'App\Controllers\MedicalController@getServiceCategories');
        
        Router::post('checkup-request', 'App\Controllers\MedicalController@createCheckupRequest')
            ->middleware(['auth']);
        Router::post('home-sampling-request', 'App\Controllers\MedicalController@createHomeSamplingRequest')
            ->middleware(['auth']);
        Router::get('my-requests', 'App\Controllers\MedicalController@getUserRequests')
            ->middleware(['auth']);
        Router::post('cancel-request', 'App\Controllers\MedicalController@cancelRequest')
            ->middleware(['auth']);
    });
    
    // مسیرهای محتوا
    Router::group(['prefix' => 'api/content'], function() {
        Router::get('blog-posts', 'App\Controllers\ContentController@getBlogPosts');
        Router::get('blog-posts/{slug}', 'App\Controllers\ContentController@getBlogPost');
        Router::get('blog-categories', 'App\Controllers\ContentController@getBlogCategories');
        Router::get('popular-posts', 'App\Controllers\ContentController@getPopularPosts');
        
        Router::post('contact', 'App\Controllers\ContentController@sendContactMessage');
        Router::post('feedback', 'App\Controllers\ContentController@submitFeedback');
        Router::get('stats', 'App\Controllers\ContentController@getStats');
    });
    
    // مسیرهای عمومی
    Router::get('api/health', function() {
        echo json_encode([
            'success' => true,
            'message' => 'API is running',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '2.0'
        ], JSON_UNESCAPED_UNICODE);
    });
    
    Router::get('api/routes', function() {
        echo json_encode([
            'success' => true,
            'routes' => Router::getRoutes()
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    });
}
