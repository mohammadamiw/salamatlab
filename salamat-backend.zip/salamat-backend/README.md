# SalamatLab Backend API

سامانه مدیریت آزمایشگاه پزشکی سلامت‌لاب - بکند API

## 🚀 ویژگی‌ها

- **معماری MVC**: ساختار منظم و قابل نگهداری
- **PDO Database**: اتصال امن به پایگاه داده
- **JWT Authentication**: احراز هویت پیشرفته
- **OTP System**: سیستم تایید شماره موبایل
- **SMS Integration**: ارسال پیامک با SMS.ir
- **Rate Limiting**: محدودیت درخواست
- **CORS Support**: پشتیبانی از Cross-Origin
- **RESTful API**: API استاندارد REST

## 📋 پیش‌نیازها

- PHP 8.2 یا بالاتر
- MySQL 8.0 یا بالاتر
- Composer
- Extension های PHP: PDO, JSON, mbstring, cURL

## 🛠️ نصب و راه‌اندازی

### 1. کلون کردن پروژه

```bash
git clone <repository-url>
cd salamat-backend
```

### 2. نصب وابستگی‌ها

```bash
composer install
```

### 3. تنظیم متغیرهای محیطی

```bash
cp env.example .env
```

فایل `.env` را ویرایش کنید:

```env
# تنظیمات پایگاه داده
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=salamatlab
DB_USERNAME=root
DB_PASSWORD=your_password

# تنظیمات JWT
JWT_SECRET=your_jwt_secret_key_here

# تنظیمات SMS
SMS_API_KEY=your_sms_api_key_here
SMS_SENDER_NUMBER=10008663
```

### 4. نصب پایگاه داده

```bash
php database/install.php
```

### 5. راه‌اندازی سرور

```bash
php -S localhost:8000 -t public
```

## 📚 API Documentation

### Authentication Endpoints

#### ارسال کد OTP
```
POST /api/auth/send-otp
Content-Type: application/json

{
    "phone": "09123456789"
}
```

#### تایید کد OTP
```
POST /api/auth/verify-otp
Content-Type: application/json

{
    "phone": "09123456789",
    "otp": "123456"
}
```

#### تکمیل پروفایل
```
POST /api/auth/complete-profile
Authorization: Bearer <token>
Content-Type: application/json

{
    "first_name": "احمد",
    "last_name": "محمدی",
    "national_id": "1234567890",
    "birth_date": "1990-01-01",
    "gender": "male"
}
```

### Medical Endpoints

#### دریافت لیست پزشکان
```
GET /api/medical/doctors?specialty=cardiology&page=1&limit=10
```

#### دریافت لیست خدمات
```
GET /api/medical/services?category=laboratory&page=1&limit=10
```

#### ثبت درخواست ویزیت
```
POST /api/medical/checkup-request
Authorization: Bearer <token>
Content-Type: application/json

{
    "doctor_id": 1,
    "service_id": 1,
    "preferred_date": "2024-01-15",
    "preferred_time": "10:00",
    "symptoms": "درد قفسه سینه",
    "notes": "درد از دیروز شروع شده"
}
```

### Content Endpoints

#### دریافت مقالات بلاگ
```
GET /api/content/blog-posts?category=health&page=1&limit=10
```

#### ارسال پیام تماس
```
POST /api/content/contact
Content-Type: application/json

{
    "name": "احمد محمدی",
    "email": "ahmad@example.com",
    "subject": "سوال در مورد آزمایش",
    "message": "سلام، می‌خواستم در مورد آزمایش خون سوال کنم"
}
```

## 🗄️ ساختار پایگاه داده

### جداول اصلی

- `users` - کاربران
- `otp_codes` - کدهای تایید
- `doctors` - پزشکان
- `medical_services` - خدمات پزشکی
- `checkup_requests` - درخواست‌های ویزیت
- `home_sampling_requests` - درخواست‌های نمونه‌گیری
- `blog_posts` - مقالات بلاگ
- `contact_messages` - پیام‌های تماس
- `feedback_surveys` - نظرسنجی‌ها

## 🔧 تنظیمات

### CORS
```php
// در config/app.php
'cors' => [
    'allowed_origins' => ['http://localhost:5173', 'http://localhost:3000'],
    'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    'allowed_headers' => ['Content-Type', 'Authorization', 'X-Requested-With']
]
```

### Rate Limiting
```php
// در config/app.php
'rate_limit' => [
    'requests' => 100,
    'window' => 3600 // ثانیه
]
```

## 🧪 تست

```bash
# اجرای تست‌ها
composer test

# تست API
curl http://localhost:8000/api/health
```

## 📝 لاگ‌ها

لاگ‌ها در پوشه `storage/logs` ذخیره می‌شوند:

- `error-YYYY-MM-DD.log` - خطاها
- `access-YYYY-MM-DD.log` - درخواست‌ها
- `sms-YYYY-MM-DD.log` - پیامک‌ها

## 🚀 استقرار

### با Docker

```dockerfile
FROM php:8.2-apache
COPY . /var/www/html/
RUN docker-php-ext-install pdo pdo_mysql
EXPOSE 80
```

### با Liara

```bash
# نصب Liara CLI
npm install -g @liara/cli

# لاگین
liara login

# استقرار
liara deploy
```

## 🤝 مشارکت

1. Fork کنید
2. Branch جدید بسازید (`git checkout -b feature/amazing-feature`)
3. Commit کنید (`git commit -m 'Add amazing feature'`)
4. Push کنید (`git push origin feature/amazing-feature`)
5. Pull Request بسازید

## 📄 مجوز

این پروژه تحت مجوز MIT منتشر شده است.

## 📞 پشتیبانی

- ایمیل: support@salamatlab.com
- تلفن: 021-12345678
- وب‌سایت: https://salamatlab.com
