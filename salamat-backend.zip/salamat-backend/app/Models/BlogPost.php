<?php

namespace App\Models;

use App\Models\BaseModel;

class BlogPost extends BaseModel
{
    protected $table = 'blog_posts';
    
    protected $fillable = [
        'title',
        'slug',
        'content',
        'excerpt',
        'category',
        'tags',
        'featured_image',
        'author_name',
        'author_email',
        'status',
        'views_count',
        'published_at',
        'created_at',
        'updated_at'
    ];
    
    protected $casts = [
        'views_count' => 'integer'
    ];

    /**
     * دریافت دسته‌بندی‌ها
     */
    public function getCategories()
    {
        $sql = "SELECT DISTINCT category FROM {$this->table} WHERE category IS NOT NULL AND status = 'published' ORDER BY category";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll(\PDO::FETCH_COLUMN);
    }

    /**
     * دریافت مقالات بر اساس دسته‌بندی
     */
    public function getByCategory($category, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE category = :category AND status = 'published' 
                ORDER BY published_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':category', $category, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * جستجوی مقالات
     */
    public function search($query, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE (title LIKE :query OR content LIKE :query OR excerpt LIKE :query OR tags LIKE :query) 
                AND status = 'published' 
                ORDER BY published_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':query', "%{$query}%", \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت مقالات محبوب
     */
    public function getPopular($limit = 5)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE status = 'published' 
                ORDER BY views_count DESC, published_at DESC 
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت مقالات اخیر
     */
    public function getRecent($limit = 5)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE status = 'published' 
                ORDER BY published_at DESC 
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * پیدا کردن مقاله بر اساس slug
     */
    public function findBySlug($slug)
    {
        $sql = "SELECT * FROM {$this->table} WHERE slug = :slug AND status = 'published'";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':slug', $slug, \PDO::PARAM_STR);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    /**
     * افزایش تعداد بازدید
     */
    public function incrementViews($postId)
    {
        $sql = "UPDATE {$this->table} SET views_count = views_count + 1 WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id', $postId, \PDO::PARAM_INT);
        
        return $stmt->execute();
    }

    /**
     * تولید slug از عنوان
     */
    public function generateSlug($title)
    {
        // تبدیل به حروف کوچک
        $slug = strtolower($title);
        
        // حذف کاراکترهای خاص
        $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
        
        // جایگزینی فاصله با خط تیره
        $slug = preg_replace('/[\s-]+/', '-', $slug);
        
        // حذف خط تیره از ابتدا و انتها
        $slug = trim($slug, '-');
        
        // بررسی یکتایی slug
        $originalSlug = $slug;
        $counter = 1;
        
        while ($this->slugExists($slug)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }

    /**
     * بررسی وجود slug
     */
    private function slugExists($slug)
    {
        $sql = "SELECT COUNT(*) FROM {$this->table} WHERE slug = :slug";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':slug', $slug, \PDO::PARAM_STR);
        $stmt->execute();
        
        return $stmt->fetchColumn() > 0;
    }
}
