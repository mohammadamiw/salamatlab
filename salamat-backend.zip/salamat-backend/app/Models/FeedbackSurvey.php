<?php

namespace App\Models;

use App\Models\BaseModel;

class FeedbackSurvey extends BaseModel
{
    protected $table = 'feedback_surveys';
    
    protected $fillable = [
        'user_id',
        'name',
        'email',
        'phone',
        'service_type',
        'rating',
        'feedback',
        'suggestions',
        'status',
        'created_at',
        'updated_at'
    ];
    
    protected $casts = [
        'user_id' => 'integer',
        'rating' => 'integer'
    ];

    /**
     * دریافت نظرسنجی‌ها بر اساس وضعیت
     */
    public function getByStatus($status, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT fs.*, 
                       u.first_name, 
                       u.last_name, 
                       u.phone as user_phone
                FROM {$this->table} fs
                LEFT JOIN users u ON fs.user_id = u.id
                WHERE fs.status = :status 
                ORDER BY fs.created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت نظرسنجی‌ها بر اساس نوع خدمت
     */
    public function getByServiceType($serviceType, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT fs.*, 
                       u.first_name, 
                       u.last_name, 
                       u.phone as user_phone
                FROM {$this->table} fs
                LEFT JOIN users u ON fs.user_id = u.id
                WHERE fs.service_type = :service_type 
                ORDER BY fs.created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':service_type', $serviceType, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت میانگین امتیاز
     */
    public function getAverageRating()
    {
        $sql = "SELECT AVG(rating) as average_rating FROM {$this->table} WHERE rating IS NOT NULL";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        $result = $stmt->fetch();
        return $result ? round($result['average_rating'], 1) : 0;
    }

    /**
     * دریافت توزیع امتیازات
     */
    public function getRatingDistribution()
    {
        $sql = "SELECT 
                    rating,
                    COUNT(*) as count
                FROM {$this->table} 
                WHERE rating IS NOT NULL 
                GROUP BY rating 
                ORDER BY rating DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        $distribution = [];
        while ($row = $stmt->fetch()) {
            $distribution[$row['rating']] = (int)$row['count'];
        }
        
        return $distribution;
    }

    /**
     * دریافت آمار نظرسنجی‌ها
     */
    public function getStats()
    {
        $sql = "SELECT 
                    status,
                    COUNT(*) as count
                FROM {$this->table} 
                GROUP BY status";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        $stats = [];
        while ($row = $stmt->fetch()) {
            $stats[$row['status']] = (int)$row['count'];
        }
        
        return $stats;
    }

    /**
     * به‌روزرسانی وضعیت نظرسنجی
     */
    public function updateStatus($feedbackId, $status)
    {
        return $this->update($feedbackId, [
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }
}
