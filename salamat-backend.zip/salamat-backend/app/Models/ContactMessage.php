<?php

namespace App\Models;

use App\Models\BaseModel;

class ContactMessage extends BaseModel
{
    protected $table = 'contact_messages';
    
    protected $fillable = [
        'name',
        'email',
        'phone',
        'subject',
        'message',
        'status',
        'response',
        'responded_at',
        'created_at',
        'updated_at'
    ];

    /**
     * دریافت پیام‌ها بر اساس وضعیت
     */
    public function getByStatus($status, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE status = :status 
                ORDER BY created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * به‌روزرسانی وضعیت پیام
     */
    public function updateStatus($messageId, $status, $response = null)
    {
        $data = [
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if ($response) {
            $data['response'] = $response;
            $data['responded_at'] = date('Y-m-d H:i:s');
        }
        
        return $this->update($messageId, $data);
    }

    /**
     * دریافت آمار پیام‌ها
     */
    public function getStats()
    {
        $sql = "SELECT 
                    status,
                    COUNT(*) as count
                FROM {$this->table} 
                GROUP BY status";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        $stats = [];
        while ($row = $stmt->fetch()) {
            $stats[$row['status']] = (int)$row['count'];
        }
        
        return $stats;
    }
}
