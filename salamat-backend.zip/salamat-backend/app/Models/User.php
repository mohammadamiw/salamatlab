<?php

require_once __DIR__ . '/BaseModel.php';

/**
 * مدل کاربر
 * User Model
 */

class User extends BaseModel
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    
    protected $fillable = [
        'phone',
        'email', 
        'first_name',
        'last_name',
        'national_id',
        'birth_date',
        'gender',
        'city',
        'province',
        'has_basic_insurance',
        'basic_insurance',
        'complementary_insurance',
        'is_profile_complete',
        'is_verified',
        'is_active'
    ];
    
    protected $hidden = [
        'password_hash'
    ];
    
    protected $casts = [
        'is_profile_complete' => 'boolean',
        'is_verified' => 'boolean',
        'is_active' => 'boolean',
        'birth_date' => 'date'
    ];
    
    /**
     * پیدا کردن کاربر بر اساس شماره تلفن
     */
    public function findByPhone(string $phone): ?array
    {
        return $this->findBy('phone', $phone);
    }
    
    /**
     * پیدا کردن کاربر بر اساس ایمیل
     */
    public function findByEmail(string $email): ?array
    {
        return $this->findBy('email', $email);
    }
    
    /**
     * ایجاد کاربر جدید
     */
    public function createUser(array $userData): array
    {
        // اعتبارسنجی داده‌ها
        $rules = [
            'phone' => 'required|mobile',
        ];
        
        $errors = $this->validate($userData, $rules);
        
        if (!empty($errors)) {
            throw new ValidationException('داده‌های کاربر نامعتبر', $errors);
        }
        
        // بررسی تکراری نبودن شماره تلفن
        $existingUser = $this->findByPhone($userData['phone']);
        if ($existingUser) {
            throw new ValidationException('کاربری با این شماره تلفن قبلاً ثبت نام کرده است');
        }
        
        // تنظیم مقادیر پیش‌فرض
        $userData['is_active'] = true;
        $userData['is_verified'] = false;
        $userData['is_profile_complete'] = false;
        
        return $this->create($userData);
    }
    
    /**
     * به‌روزرسانی پروفایل کاربر
     */
    public function updateProfile(int $userId, array $profileData): ?array
    {
        // اعتبارسنجی داده‌های پروفایل
        $rules = [
            'first_name' => 'required|min:2|max:50',
            'last_name' => 'required|min:2|max:50',
            'gender' => 'in:male,female',
            'has_basic_insurance' => 'in:yes,no'
        ];
        
        if (isset($profileData['email'])) {
            $rules['email'] = 'email';
        }
        
        if (isset($profileData['national_id'])) {
            $rules['national_id'] = 'national_id';
        }
        
        $errors = $this->validate($profileData, $rules);
        
        if (!empty($errors)) {
            throw new ValidationException('داده‌های پروفایل نامعتبر', $errors);
        }
        
        // بررسی تکراری نبودن کد ملی
        if (isset($profileData['national_id'])) {
            $existingUser = $this->db->fetch(
                "SELECT id FROM users WHERE national_id = ? AND id != ?",
                [$profileData['national_id'], $userId]
            );
            
            if ($existingUser) {
                throw new ValidationException('کاربری با این کد ملی قبلاً ثبت نام کرده است');
            }
        }
        
        // بررسی تکمیل پروفایل
        $requiredFields = ['first_name', 'last_name', 'birth_date', 'gender', 'city'];
        $isComplete = true;
        
        foreach ($requiredFields as $field) {
            $value = $profileData[$field] ?? null;
            if (empty($value)) {
                $isComplete = false;
                break;
            }
        }
        
        if ($isComplete) {
            $profileData['is_profile_complete'] = true;
        }
        
        return $this->update($userId, $profileData);
    }
    
    /**
     * تأیید کاربر
     */
    public function verifyUser(int $userId): ?array
    {
        return $this->update($userId, ['is_verified' => true]);
    }
    
    /**
     * غیرفعال کردن کاربر
     */
    public function deactivateUser(int $userId): ?array
    {
        return $this->update($userId, ['is_active' => false]);
    }
    
    /**
     * دریافت آدرس‌های کاربر
     */
    public function getUserAddresses(int $userId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM user_addresses 
             WHERE user_id = ? AND is_active = 1 
             ORDER BY is_default DESC, id DESC",
            [$userId]
        );
    }
    
    /**
     * دریافت درخواست‌های چکاپ کاربر
     */
    public function getUserCheckups(int $userId, int $page = 1, int $perPage = 15): array
    {
        $offset = ($page - 1) * $perPage;
        
        // شمارش کل
        $total = $this->db->fetch(
            "SELECT COUNT(*) as total FROM checkup_requests WHERE user_id = ?",
            [$userId]
        )['total'];
        
        // دریافت داده‌ها
        $checkups = $this->db->fetchAll(
            "SELECT cr.*, ms.name as service_name, d.first_name as doctor_first_name, d.last_name as doctor_last_name
             FROM checkup_requests cr
             LEFT JOIN medical_services ms ON cr.service_id = ms.id
             LEFT JOIN doctors d ON cr.doctor_id = d.id
             WHERE cr.user_id = ?
             ORDER BY cr.id DESC
             LIMIT ? OFFSET ?",
            [$userId, $perPage, $offset]
        );
        
        return [
            'data' => $checkups,
            'pagination' => [
                'currentPage' => $page,
                'perPage' => $perPage,
                'total' => (int)$total,
                'totalPages' => ceil($total / $perPage)
            ]
        ];
    }
    
    /**
     * دریافت درخواست‌های نمونه‌گیری کاربر
     */
    public function getUserHomeSampling(int $userId, int $page = 1, int $perPage = 15): array
    {
        $offset = ($page - 1) * $perPage;
        
        // شمارش کل
        $total = $this->db->fetch(
            "SELECT COUNT(*) as total FROM home_sampling_requests WHERE user_id = ?",
            [$userId]
        )['total'];
        
        // دریافت داده‌ها
        $requests = $this->db->fetchAll(
            "SELECT * FROM home_sampling_requests
             WHERE user_id = ?
             ORDER BY id DESC
             LIMIT ? OFFSET ?",
            [$userId, $perPage, $offset]
        );
        
        return [
            'data' => $requests,
            'pagination' => [
                'currentPage' => $page,
                'perPage' => $perPage,
                'total' => (int)$total,
                'totalPages' => ceil($total / $perPage)
            ]
        ];
    }
    
    /**
     * آمار کاربر
     */
    public function getUserStats(int $userId): array
    {
        return [
            'total_checkups' => $this->db->fetch(
                "SELECT COUNT(*) as count FROM checkup_requests WHERE user_id = ?",
                [$userId]
            )['count'],
            
            'completed_checkups' => $this->db->fetch(
                "SELECT COUNT(*) as count FROM checkup_requests WHERE user_id = ? AND status = 'completed'",
                [$userId]
            )['count'],
            
            'pending_checkups' => $this->db->fetch(
                "SELECT COUNT(*) as count FROM checkup_requests WHERE user_id = ? AND status IN ('pending', 'confirmed')",
                [$userId]
            )['count'],
            
            'total_home_sampling' => $this->db->fetch(
                "SELECT COUNT(*) as count FROM home_sampling_requests WHERE user_id = ?",
                [$userId]
            )['count'],
            
            'profile_completion' => $this->getProfileCompletion($userId)
        ];
    }
    
    /**
     * محاسبه درصد تکمیل پروفایل
     */
    private function getProfileCompletion(int $userId): int
    {
        $user = $this->find($userId);
        if (!$user) return 0;
        
        $fields = [
            'first_name', 'last_name', 'email', 'national_id', 
            'birth_date', 'gender', 'city', 'province'
        ];
        
        $completedFields = 0;
        foreach ($fields as $field) {
            if (!empty($user[$field])) {
                $completedFields++;
            }
        }
        
        return (int)(($completedFields / count($fields)) * 100);
    }
}

/**
 * کلاس استثناء اعتبارسنجی
 */
class ValidationException extends Exception
{
    private $errors;
    
    public function __construct(string $message, $errors = [])
    {
        parent::__construct($message);
        $this->errors = $errors;
    }
    
    public function getErrors()
    {
        return $this->errors;
    }
}
