<?php

namespace App\Models;

use App\Models\BaseModel;

class HomeSamplingRequest extends BaseModel
{
    protected $table = 'home_sampling_requests';
    
    protected $fillable = [
        'user_id',
        'service_id',
        'preferred_date',
        'preferred_time',
        'address',
        'phone',
        'notes',
        'status',
        'appointment_date',
        'appointment_time',
        'created_at',
        'updated_at'
    ];
    
    protected $casts = [
        'user_id' => 'integer',
        'service_id' => 'integer'
    ];

    /**
     * دریافت درخواست‌های کاربر
     */
    public function getByUserId($userId, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT hsr.*, 
                       ms.name as service_name,
                       ms.price as service_price,
                       ms.category as service_category
                FROM {$this->table} hsr
                LEFT JOIN medical_services ms ON hsr.service_id = ms.id
                WHERE hsr.user_id = :user_id 
                ORDER BY hsr.created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':user_id', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت درخواست‌های بر اساس وضعیت
     */
    public function getByStatus($status, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT hsr.*, 
                       u.first_name, 
                       u.last_name, 
                       u.phone as user_phone,
                       ms.name as service_name,
                       ms.price as service_price,
                       ms.category as service_category
                FROM {$this->table} hsr
                LEFT JOIN users u ON hsr.user_id = u.id
                LEFT JOIN medical_services ms ON hsr.service_id = ms.id
                WHERE hsr.status = :status 
                ORDER BY hsr.created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * به‌روزرسانی وضعیت درخواست
     */
    public function updateStatus($requestId, $status, $appointmentDate = null, $appointmentTime = null)
    {
        $data = [
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if ($appointmentDate) {
            $data['appointment_date'] = $appointmentDate;
        }
        
        if ($appointmentTime) {
            $data['appointment_time'] = $appointmentTime;
        }
        
        return $this->update($requestId, $data);
    }

    /**
     * دریافت آمار درخواست‌ها
     */
    public function getStats()
    {
        $sql = "SELECT 
                    status,
                    COUNT(*) as count
                FROM {$this->table} 
                GROUP BY status";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        $stats = [];
        while ($row = $stmt->fetch()) {
            $stats[$row['status']] = (int)$row['count'];
        }
        
        return $stats;
    }

    /**
     * دریافت درخواست‌های امروز
     */
    public function getTodayRequests()
    {
        $today = date('Y-m-d');
        
        $sql = "SELECT hsr.*, 
                       u.first_name, 
                       u.last_name, 
                       u.phone as user_phone,
                       ms.name as service_name
                FROM {$this->table} hsr
                LEFT JOIN users u ON hsr.user_id = u.id
                LEFT JOIN medical_services ms ON hsr.service_id = ms.id
                WHERE hsr.appointment_date = :today 
                AND hsr.status IN ('confirmed', 'in_progress')
                ORDER BY hsr.appointment_time ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':today', $today, \PDO::PARAM_STR);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}
