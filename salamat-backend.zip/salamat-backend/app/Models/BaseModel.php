<?php

/**
 * کلاس پایه مدل
 * Base Model Class
 * 
 * ارائه قابلیت‌های پایه ORM برای مدل‌ها
 */

abstract class BaseModel
{
    protected $db;
    protected $table;
    protected $primaryKey = 'id';
    protected $timestamps = true;
    protected $fillable = [];
    protected $hidden = [];
    protected $casts = [];
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * پیدا کردن رکورد بر اساس ID
     */
    public function find(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ? LIMIT 1";
        $result = $this->db->fetch($sql, [$id]);
        
        return $result ? $this->processResult($result) : null;
    }
    
    /**
     * پیدا کردن رکورد بر اساس شرط
     */
    public function findBy(string $column, $value): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$column} = ? LIMIT 1";
        $result = $this->db->fetch($sql, [$value]);
        
        return $result ? $this->processResult($result) : null;
    }
    
    /**
     * دریافت همه رکوردها
     */
    public function all(array $conditions = []): array
    {
        $sql = "SELECT * FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $column => $value) {
                $whereClause[] = "{$column} = ?";
                $params[] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        $sql .= " ORDER BY {$this->primaryKey} DESC";
        
        $results = $this->db->fetchAll($sql, $params);
        
        return array_map([$this, 'processResult'], $results);
    }
    
    /**
     * دریافت رکوردها با صفحه‌بندی
     */
    public function paginate(int $page = 1, int $perPage = 15, array $conditions = []): array
    {
        $offset = ($page - 1) * $perPage;
        
        // شمارش کل رکوردها
        $countSql = "SELECT COUNT(*) as total FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $column => $value) {
                $whereClause[] = "{$column} = ?";
                $params[] = $value;
            }
            $countSql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        $totalResult = $this->db->fetch($countSql, $params);
        $total = (int)$totalResult['total'];
        
        // دریافت داده‌ها
        $dataSql = "SELECT * FROM {$this->table}";
        if (!empty($conditions)) {
            $dataSql .= " WHERE " . implode(' AND ', $whereClause);
        }
        $dataSql .= " ORDER BY {$this->primaryKey} DESC LIMIT {$perPage} OFFSET {$offset}";
        
        $results = $this->db->fetchAll($dataSql, $params);
        $data = array_map([$this, 'processResult'], $results);
        
        return [
            'data' => $data,
            'pagination' => [
                'currentPage' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'totalPages' => ceil($total / $perPage),
                'hasNext' => $page < ceil($total / $perPage),
                'hasPrev' => $page > 1
            ]
        ];
    }
    
    /**
     * ایجاد رکورد جدید
     */
    public function create(array $data): array
    {
        // فیلتر کردن داده‌ها بر اساس fillable
        if (!empty($this->fillable)) {
            $data = array_intersect_key($data, array_flip($this->fillable));
        }
        
        // اضافه کردن timestamps
        if ($this->timestamps) {
            $now = date('Y-m-d H:i:s');
            $data['created_at'] = $now;
            $data['updated_at'] = $now;
        }
        
        $id = $this->db->insert($this->table, $data);
        
        return $this->find((int)$id);
    }
    
    /**
     * به‌روزرسانی رکورد
     */
    public function update(int $id, array $data): ?array
    {
        // فیلتر کردن داده‌ها بر اساس fillable
        if (!empty($this->fillable)) {
            $data = array_intersect_key($data, array_flip($this->fillable));
        }
        
        // اضافه کردن timestamp
        if ($this->timestamps) {
            $data['updated_at'] = date('Y-m-d H:i:s');
        }
        
        $affected = $this->db->update(
            $this->table, 
            $data, 
            "{$this->primaryKey} = ?", 
            [$id]
        );
        
        return $affected > 0 ? $this->find($id) : null;
    }
    
    /**
     * حذف رکورد
     */
    public function delete(int $id): bool
    {
        $affected = $this->db->delete(
            $this->table, 
            "{$this->primaryKey} = ?", 
            [$id]
        );
        
        return $affected > 0;
    }
    
    /**
     * جستجو در رکوردها
     */
    public function search(string $query, array $columns = [], int $limit = 50): array
    {
        if (empty($columns)) {
            throw new InvalidArgumentException('Search columns must be specified');
        }
        
        $whereClause = [];
        $params = [];
        
        foreach ($columns as $column) {
            $whereClause[] = "{$column} LIKE ?";
            $params[] = "%{$query}%";
        }
        
        $sql = "SELECT * FROM {$this->table} WHERE " . implode(' OR ', $whereClause) . 
               " ORDER BY {$this->primaryKey} DESC LIMIT {$limit}";
        
        $results = $this->db->fetchAll($sql, $params);
        
        return array_map([$this, 'processResult'], $results);
    }
    
    /**
     * شمارش رکوردها
     */
    public function count(array $conditions = []): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $column => $value) {
                $whereClause[] = "{$column} = ?";
                $params[] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        $result = $this->db->fetch($sql, $params);
        return (int)$result['total'];
    }
    
    /**
     * اجرای SQL خام
     */
    public function raw(string $sql, array $params = []): array
    {
        $results = $this->db->fetchAll($sql, $params);
        return array_map([$this, 'processResult'], $results);
    }
    
    /**
     * پردازش نتایج (casting و حذف فیلدهای مخفی)
     */
    protected function processResult(array $result): array
    {
        // اعمال casting
        foreach ($this->casts as $field => $type) {
            if (isset($result[$field])) {
                $result[$field] = $this->castAttribute($result[$field], $type);
            }
        }
        
        // حذف فیلدهای مخفی
        if (!empty($this->hidden)) {
            $result = array_diff_key($result, array_flip($this->hidden));
        }
        
        return $result;
    }
    
    /**
     * تبدیل نوع داده
     */
    private function castAttribute($value, string $type)
    {
        if ($value === null) {
            return null;
        }
        
        switch ($type) {
            case 'int':
            case 'integer':
                return (int)$value;
                
            case 'float':
            case 'double':
                return (float)$value;
                
            case 'bool':
            case 'boolean':
                return (bool)$value;
                
            case 'string':
                return (string)$value;
                
            case 'array':
            case 'json':
                return is_string($value) ? json_decode($value, true) : $value;
                
            case 'datetime':
                return $value instanceof DateTime ? $value : new DateTime($value);
                
            default:
                return $value;
        }
    }
    
    /**
     * اعتبارسنجی داده‌ها
     */
    protected function validate(array $data, array $rules): array
    {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            
            // بررسی required
            if (strpos($rule, 'required') !== false && empty($value)) {
                $errors[$field] = "فیلد {$field} الزامی است";
                continue;
            }
            
            // بررسی min length
            if (preg_match('/min:(\d+)/', $rule, $matches) && strlen($value) < $matches[1]) {
                $errors[$field] = "فیلد {$field} باید حداقل {$matches[1]} کاراکتر باشد";
            }
            
            // بررسی max length
            if (preg_match('/max:(\d+)/', $rule, $matches) && strlen($value) > $matches[1]) {
                $errors[$field] = "فیلد {$field} باید حداکثر {$matches[1]} کاراکتر باشد";
            }
            
            // بررسی ایمیل
            if (strpos($rule, 'email') !== false && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                $errors[$field] = "فیلد {$field} باید ایمیل معتبر باشد";
            }
            
            // بررسی شماره موبایل
            if (strpos($rule, 'mobile') !== false && !preg_match('/^09\d{9}$/', $value)) {
                $errors[$field] = "فیلد {$field} باید شماره موبایل معتبر باشد";
            }
        }
        
        return $errors;
    }
}
