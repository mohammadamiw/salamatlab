<?php

namespace App\Models;

use App\Models\BaseModel;

class CheckupRequest extends BaseModel
{
    protected $table = 'checkup_requests';
    
    protected $fillable = [
        'user_id',
        'doctor_id',
        'service_id',
        'preferred_date',
        'preferred_time',
        'symptoms',
        'notes',
        'status',
        'appointment_date',
        'appointment_time',
        'created_at',
        'updated_at'
    ];
    
    protected $casts = [
        'user_id' => 'integer',
        'doctor_id' => 'integer',
        'service_id' => 'integer'
    ];

    /**
     * دریافت درخواست‌های کاربر
     */
    public function getByUserId($userId, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT cr.*, 
                       d.name as doctor_name, 
                       d.specialty as doctor_specialty,
                       ms.name as service_name,
                       ms.price as service_price
                FROM {$this->table} cr
                LEFT JOIN doctors d ON cr.doctor_id = d.id
                LEFT JOIN medical_services ms ON cr.service_id = ms.id
                WHERE cr.user_id = :user_id 
                ORDER BY cr.created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':user_id', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت درخواست‌های پزشک
     */
    public function getByDoctorId($doctorId, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT cr.*, 
                       u.first_name, 
                       u.last_name, 
                       u.phone,
                       ms.name as service_name,
                       ms.price as service_price
                FROM {$this->table} cr
                LEFT JOIN users u ON cr.user_id = u.id
                LEFT JOIN medical_services ms ON cr.service_id = ms.id
                WHERE cr.doctor_id = :doctor_id 
                ORDER BY cr.created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':doctor_id', $doctorId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت درخواست‌های بر اساس وضعیت
     */
    public function getByStatus($status, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT cr.*, 
                       u.first_name, 
                       u.last_name, 
                       u.phone,
                       d.name as doctor_name, 
                       d.specialty as doctor_specialty,
                       ms.name as service_name,
                       ms.price as service_price
                FROM {$this->table} cr
                LEFT JOIN users u ON cr.user_id = u.id
                LEFT JOIN doctors d ON cr.doctor_id = d.id
                LEFT JOIN medical_services ms ON cr.service_id = ms.id
                WHERE cr.status = :status 
                ORDER BY cr.created_at DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * به‌روزرسانی وضعیت درخواست
     */
    public function updateStatus($requestId, $status, $appointmentDate = null, $appointmentTime = null)
    {
        $data = [
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if ($appointmentDate) {
            $data['appointment_date'] = $appointmentDate;
        }
        
        if ($appointmentTime) {
            $data['appointment_time'] = $appointmentTime;
        }
        
        return $this->update($requestId, $data);
    }

    /**
     * دریافت آمار درخواست‌ها
     */
    public function getStats()
    {
        $sql = "SELECT 
                    status,
                    COUNT(*) as count
                FROM {$this->table} 
                GROUP BY status";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        $stats = [];
        while ($row = $stmt->fetch()) {
            $stats[$row['status']] = (int)$row['count'];
        }
        
        return $stats;
    }
}
