<?php

namespace App\Models;

use App\Models\BaseModel;

class Doctor extends BaseModel
{
    protected $table = 'doctors';
    
    protected $fillable = [
        'name',
        'specialty',
        'education',
        'experience_years',
        'description',
        'image_url',
        'phone',
        'email',
        'consultation_fee',
        'is_available',
        'rating',
        'review_count',
        'created_at',
        'updated_at'
    ];
    
    protected $casts = [
        'experience_years' => 'integer',
        'consultation_fee' => 'float',
        'is_available' => 'boolean',
        'rating' => 'float',
        'review_count' => 'integer'
    ];

    /**
     * دریافت لیست تخصص‌ها
     */
    public function getSpecialties()
    {
        $sql = "SELECT DISTINCT specialty FROM {$this->table} WHERE specialty IS NOT NULL ORDER BY specialty";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll(\PDO::FETCH_COLUMN);
    }

    /**
     * جستجوی پزشکان بر اساس تخصص
     */
    public function getBySpecialty($specialty, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE specialty = :specialty AND is_available = 1 
                ORDER BY rating DESC, review_count DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':specialty', $specialty, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * جستجوی پزشکان
     */
    public function search($query, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE (name LIKE :query OR specialty LIKE :query OR description LIKE :query) 
                AND is_available = 1 
                ORDER BY rating DESC, review_count DESC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':query', "%{$query}%", \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت پزشکان محبوب
     */
    public function getPopular($limit = 5)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE is_available = 1 
                ORDER BY rating DESC, review_count DESC 
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * به‌روزرسانی امتیاز پزشک
     */
    public function updateRating($doctorId, $newRating)
    {
        $doctor = $this->find($doctorId);
        if (!$doctor) {
            return false;
        }
        
        $currentRating = $doctor['rating'] ?? 0;
        $currentCount = $doctor['review_count'] ?? 0;
        
        // محاسبه امتیاز جدید
        $totalRating = ($currentRating * $currentCount) + $newRating;
        $newCount = $currentCount + 1;
        $averageRating = $totalRating / $newCount;
        
        return $this->update($doctorId, [
            'rating' => round($averageRating, 1),
            'review_count' => $newCount,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }
}
