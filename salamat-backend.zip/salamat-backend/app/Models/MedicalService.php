<?php

namespace App\Models;

use App\Models\BaseModel;

class MedicalService extends BaseModel
{
    protected $table = 'medical_services';
    
    protected $fillable = [
        'name',
        'category',
        'description',
        'price',
        'duration_minutes',
        'is_available',
        'image_url',
        'requirements',
        'preparation_instructions',
        'created_at',
        'updated_at'
    ];
    
    protected $casts = [
        'price' => 'float',
        'duration_minutes' => 'integer',
        'is_available' => 'boolean'
    ];

    /**
     * دریافت دسته‌بندی‌ها
     */
    public function getCategories()
    {
        $sql = "SELECT DISTINCT category FROM {$this->table} WHERE category IS NOT NULL ORDER BY category";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        
        return $stmt->fetchAll(\PDO::FETCH_COLUMN);
    }

    /**
     * دریافت خدمات بر اساس دسته‌بندی
     */
    public function getByCategory($category, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE category = :category AND is_available = 1 
                ORDER BY name ASC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':category', $category, \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * جستجوی خدمات
     */
    public function search($query, $page = 1, $limit = 10)
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE (name LIKE :query OR description LIKE :query OR category LIKE :query) 
                AND is_available = 1 
                ORDER BY name ASC 
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':query', "%{$query}%", \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * دریافت خدمات محبوب
     */
    public function getPopular($limit = 5)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE is_available = 1 
                ORDER BY name ASC 
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}
