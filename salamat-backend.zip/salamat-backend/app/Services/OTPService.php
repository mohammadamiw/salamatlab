<?php

/**
 * سرویس OTP
 * OTP Service
 * 
 * مدیریت تولید، ذخیره‌سازی و اعتبارسنجی کدهای یکبار مصرف
 */

class OTPService
{
    private $db;
    private $config;
    private $smsService;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->config = require __DIR__ . '/../../config/app.php';
        $this->smsService = new SMSService();
    }
    
    /**
     * ارسال کد OTP
     */
    public function sendOTP(string $phone, string $purpose = 'login'): array
    {
        try {
            // پاک‌سازی کدهای منقضی
            $this->cleanupExpiredCodes($phone);
            
            // بررسی محدودیت زمانی
            if ($this->hasRecentOTP($phone)) {
                return [
                    'success' => false,
                    'message' => 'لطفاً ۶۰ ثانیه صبر کنید و مجدداً تلاش کنید'
                ];
            }
            
            // تولید کد OTP
            $code = $this->generateOTPCode();
            $expiresAt = date('Y-m-d H:i:s', time() + $this->config['security']['otp_expire']);
            
            // ذخیره در دیتابیس
            $this->db->query(
                "INSERT INTO otp_codes (phone, code, purpose, expires_at, created_at) 
                 VALUES (?, ?, ?, ?, NOW())",
                [$phone, $code, $purpose, $expiresAt]
            );
            
            // ارسال پیامک
            $smsResult = $this->smsService->sendOTP($phone, $code);
            
            if (!$smsResult['success']) {
                return [
                    'success' => false,
                    'message' => 'خطا در ارسال پیامک: ' . $smsResult['message']
                ];
            }
            
            return [
                'success' => true,
                'message' => 'کد تأیید برای شما ارسال شد',
                'expires_in' => $this->config['security']['otp_expire']
            ];
            
        } catch (Exception $e) {
            error_log("OTP Send Error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'خطا در ارسال کد تأیید'
            ];
        }
    }
    
    /**
     * تأیید کد OTP
     */
    public function verifyOTP(string $phone, string $code, string $purpose = 'login'): array
    {
        try {
            // پاک‌سازی کدهای منقضی
            $this->cleanupExpiredCodes($phone);
            
            // پیدا کردن کد معتبر
            $otpRecord = $this->db->fetch(
                "SELECT * FROM otp_codes 
                 WHERE phone = ? AND code = ? AND purpose = ? 
                 AND is_used = 0 AND expires_at > NOW() 
                 ORDER BY id DESC LIMIT 1",
                [$phone, $code, $purpose]
            );
            
            if (!$otpRecord) {
                // افزایش تعداد تلاش‌های ناموفق
                $this->incrementFailedAttempts($phone);
                
                return [
                    'success' => false,
                    'message' => 'کد تأیید نامعتبر یا منقضی شده است'
                ];
            }
            
            // بررسی حداکثر تلاش‌ها
            if ($otpRecord['attempts'] >= $otpRecord['max_attempts']) {
                return [
                    'success' => false,
                    'message' => 'تعداد تلاش‌های مجاز تمام شده است. مجدداً درخواست کنید'
                ];
            }
            
            // علامت‌گذاری به عنوان استفاده شده
            $this->db->query(
                "UPDATE otp_codes SET is_used = 1, used_at = NOW() WHERE id = ?",
                [$otpRecord['id']]
            );
            
            // پاک کردن سایر کدهای این شماره
            $this->db->query(
                "UPDATE otp_codes SET is_used = 1 
                 WHERE phone = ? AND id != ? AND is_used = 0",
                [$phone, $otpRecord['id']]
            );
            
            return [
                'success' => true,
                'message' => 'کد تأیید با موفقیت تأیید شد'
            ];
            
        } catch (Exception $e) {
            error_log("OTP Verify Error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'خطا در تأیید کد'
            ];
        }
    }
    
    /**
     * تولید کد OTP
     */
    private function generateOTPCode(): string
    {
        return str_pad(random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
    }
    
    /**
     * بررسی وجود OTP اخیر
     */
    private function hasRecentOTP(string $phone): bool
    {
        $recentOTP = $this->db->fetch(
            "SELECT id FROM otp_codes 
             WHERE phone = ? AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)",
            [$phone]
        );
        
        return $recentOTP !== null;
    }
    
    /**
     * افزایش تعداد تلاش‌های ناموفق
     */
    private function incrementFailedAttempts(string $phone): void
    {
        $this->db->query(
            "UPDATE otp_codes 
             SET attempts = attempts + 1 
             WHERE phone = ? AND is_used = 0 AND expires_at > NOW()",
            [$phone]
        );
    }
    
    /**
     * پاک‌سازی کدهای منقضی
     */
    private function cleanupExpiredCodes(string $phone): void
    {
        $this->db->query(
            "DELETE FROM otp_codes 
             WHERE phone = ? AND (expires_at < NOW() OR created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR))",
            [$phone]
        );
    }
    
    /**
     * پاک‌سازی عمومی کدهای منقضی
     */
    public function cleanupAllExpiredCodes(): void
    {
        $this->db->query(
            "DELETE FROM otp_codes 
             WHERE expires_at < NOW() OR created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        );
    }
    
    /**
     * آمار OTP
     */
    public function getOTPStats(): array
    {
        return [
            'total_sent_today' => $this->db->fetch(
                "SELECT COUNT(*) as count FROM otp_codes WHERE DATE(created_at) = CURDATE()"
            )['count'],
            
            'total_verified_today' => $this->db->fetch(
                "SELECT COUNT(*) as count FROM otp_codes 
                 WHERE DATE(used_at) = CURDATE() AND is_used = 1"
            )['count'],
            
            'success_rate_today' => $this->getSuccessRate(),
            
            'pending_codes' => $this->db->fetch(
                "SELECT COUNT(*) as count FROM otp_codes 
                 WHERE is_used = 0 AND expires_at > NOW()"
            )['count']
        ];
    }
    
    /**
     * محاسبه نرخ موفقیت
     */
    private function getSuccessRate(): float
    {
        $sent = $this->db->fetch(
            "SELECT COUNT(*) as count FROM otp_codes WHERE DATE(created_at) = CURDATE()"
        )['count'];
        
        $verified = $this->db->fetch(
            "SELECT COUNT(*) as count FROM otp_codes 
             WHERE DATE(used_at) = CURDATE() AND is_used = 1"
        )['count'];
        
        return $sent > 0 ? round(($verified / $sent) * 100, 2) : 0;
    }
}
