<?php

/**
 * سرویس پیامک
 * SMS Service
 * 
 * ارسال پیامک از طریق SMS.ir
 */

class SMSService
{
    private $config;
    private $apiKey;
    private $apiUrl;
    
    public function __construct()
    {
        $this->config = require __DIR__ . '/../../config/app.php';
        $this->apiKey = $this->config['sms']['api_key'];
        $this->apiUrl = $this->config['sms']['api_url'];
    }
    
    /**
     * ارسال پیامک OTP
     */
    public function sendOTP(string $phone, string $code): array
    {
        if (empty($this->apiKey)) {
            return [
                'success' => false,
                'message' => 'کلید API پیامک تنظیم نشده است'
            ];
        }
        
        $templateId = $this->config['sms']['templates']['otp'];
        
        if (!$templateId) {
            return [
                'success' => false,
                'message' => 'شناسه قالب OTP تنظیم نشده است'
            ];
        }
        
        return $this->sendTemplate($phone, $templateId, [
            'Code' => $code
        ]);
    }
    
    /**
     * ارسال پیامک تأیید چکاپ
     */
    public function sendCheckupConfirmation(string $phone, string $name): array
    {
        $templateId = $this->config['sms']['templates']['checkup_confirm'];
        
        if (!$templateId) {
            return [
                'success' => false,
                'message' => 'شناسه قالب تأیید چکاپ تنظیم نشده است'
            ];
        }
        
        return $this->sendTemplate($phone, $templateId, [
            'NAME' => $name
        ]);
    }
    
    /**
     * ارسال پیامک اطلاع‌رسانی به کارکنان
     */
    public function sendStaffNotification(string $link): array
    {
        $staffMobile = $this->config['sms']['staff_mobile'];
        
        if (empty($staffMobile)) {
            return [
                'success' => false,
                'message' => 'شماره موبایل کارکنان تنظیم نشده است'
            ];
        }
        
        $templateId = $this->config['sms']['templates']['staff_notify'];
        
        if (!$templateId) {
            return [
                'success' => false,
                'message' => 'شناسه قالب اطلاع‌رسانی تنظیم نشده است'
            ];
        }
        
        return $this->sendTemplate($staffMobile, $templateId, [
            'LINK' => $link
        ]);
    }
    
    /**
     * ارسال پیامک بر اساس قالب
     */
    private function sendTemplate(string $phone, int $templateId, array $parameters = []): array
    {
        try {
            // تنظیم داده‌های درخواست
            $requestData = [
                'mobile' => $this->formatPhone($phone),
                'templateId' => $templateId,
                'parameters' => []
            ];
            
            // تبدیل پارامترها به فرمت مورد نیاز SMS.ir
            foreach ($parameters as $name => $value) {
                $requestData['parameters'][] = [
                    'name' => $name,
                    'value' => (string)$value
                ];
            }
            
            // ارسال درخواست
            $response = $this->sendRequest($requestData);
            
            if ($response['success']) {
                $this->logSMS($phone, $templateId, $parameters, 'success', $response);
                
                return [
                    'success' => true,
                    'message' => 'پیامک با موفقیت ارسال شد',
                    'message_id' => $response['data']['messageId'] ?? null
                ];
            } else {
                $this->logSMS($phone, $templateId, $parameters, 'failed', $response);
                
                return [
                    'success' => false,
                    'message' => $response['message'] ?? 'خطا در ارسال پیامک'
                ];
            }
            
        } catch (Exception $e) {
            $this->logSMS($phone, $templateId, $parameters, 'error', ['error' => $e->getMessage()]);
            
            return [
                'success' => false,
                'message' => 'خطا در ارسال پیامک: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * ارسال درخواست HTTP
     */
    private function sendRequest(array $data): array
    {
        $jsonData = json_encode($data, JSON_UNESCAPED_UNICODE);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->apiUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $jsonData,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'x-api-key: ' . $this->apiKey,
                'Accept: application/json'
            ],
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        if ($curlError) {
            throw new Exception("CURL Error: " . $curlError);
        }
        
        if ($httpCode !== 200) {
            return [
                'success' => false,
                'message' => "HTTP Error: {$httpCode}",
                'response' => $response
            ];
        }
        
        $responseData = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("JSON Decode Error: " . json_last_error_msg());
        }
        
        // بررسی پاسخ SMS.ir
        if (isset($responseData['status']) && (int)$responseData['status'] === 1) {
            return [
                'success' => true,
                'data' => $responseData['data'] ?? [],
                'message' => $responseData['message'] ?? 'موفق'
            ];
        } else {
            return [
                'success' => false,
                'message' => $responseData['message'] ?? 'خطای نامشخص',
                'error_code' => $responseData['status'] ?? 'unknown'
            ];
        }
    }
    
    /**
     * فرمت کردن شماره تلفن
     */
    private function formatPhone(string $phone): string
    {
        // حذف کاراکترهای غیرعددی
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        // حذف کد کشور ایران
        if (strpos($phone, '98') === 0) {
            $phone = substr($phone, 2);
        }
        
        // حذف صفر ابتدایی
        if (strpos($phone, '0') === 0) {
            $phone = substr($phone, 1);
        }
        
        // بررسی صحت شماره
        if (!preg_match('/^9\d{9}$/', $phone)) {
            throw new Exception('شماره موبایل نامعتبر است');
        }
        
        return $phone;
    }
    
    /**
     * لاگ کردن پیامک
     */
    private function logSMS(string $phone, int $templateId, array $parameters, string $status, array $response): void
    {
        try {
            $logData = [
                'timestamp' => date('Y-m-d H:i:s'),
                'phone' => $phone,
                'template_id' => $templateId,
                'parameters' => $parameters,
                'status' => $status,
                'response' => $response
            ];
            
            $logLine = json_encode($logData, JSON_UNESCAPED_UNICODE) . "\n";
            $logFile = __DIR__ . '/../../storage/logs/sms-' . date('Y-m-d') . '.log';
            
            // اطمینان از وجود پوشه logs
            $logDir = dirname($logFile);
            if (!is_dir($logDir)) {
                mkdir($logDir, 0755, true);
            }
            
            file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
            
        } catch (Exception $e) {
            error_log("SMS Log Error: " . $e->getMessage());
        }
    }
    
    /**
     * آمار پیامک
     */
    public function getSMSStats(): array
    {
        $today = date('Y-m-d');
        $logFile = __DIR__ . '/../../storage/logs/sms-' . $today . '.log';
        
        if (!file_exists($logFile)) {
            return [
                'total_sent' => 0,
                'successful' => 0,
                'failed' => 0,
                'success_rate' => 0
            ];
        }
        
        $logs = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $stats = [
            'total_sent' => 0,
            'successful' => 0,
            'failed' => 0
        ];
        
        foreach ($logs as $line) {
            $data = json_decode($line, true);
            if ($data) {
                $stats['total_sent']++;
                if ($data['status'] === 'success') {
                    $stats['successful']++;
                } else {
                    $stats['failed']++;
                }
            }
        }
        
        $stats['success_rate'] = $stats['total_sent'] > 0 
            ? round(($stats['successful'] / $stats['total_sent']) * 100, 2)
            : 0;
        
        return $stats;
    }
}
