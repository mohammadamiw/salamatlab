<?php

/**
 * Rate Limit Middleware
 * 
 * محدودسازی تعداد درخواست‌ها
 */

class RateLimitMiddleware
{
    private $config;
    private $storageDir;
    
    public function __construct()
    {
        $this->config = require __DIR__ . '/../../config/app.php';
        $this->storageDir = __DIR__ . '/../../storage/rate_limit/';
        
        // ایجاد پوشه ذخیره‌سازی
        if (!is_dir($this->storageDir)) {
            mkdir($this->storageDir, 0755, true);
        }
    }
    
    /**
     * اجرای middleware
     */
    public function handle(): void
    {
        $ip = $this->getClientIP();
        $rateLimit = $this->config['security']['rate_limit'] ?? 100; // درخواست در ساعت
        $window = 3600; // پنجره زمانی 1 ساعت (ثانیه)
        
        if ($this->exceedsRateLimit($ip, $rateLimit, $window)) {
            $this->tooManyRequests();
        }
        
        $this->recordRequest($ip);
    }
    
    /**
     * بررسی تجاوز از حد مجاز
     */
    private function exceedsRateLimit(string $ip, int $limit, int $window): bool
    {
        $requests = $this->getRequests($ip, $window);
        return count($requests) >= $limit;
    }
    
    /**
     * دریافت درخواست‌های اخیر
     */
    private function getRequests(string $ip, int $window): array
    {
        $filename = $this->getStorageFile($ip);
        
        if (!file_exists($filename)) {
            return [];
        }
        
        $content = file_get_contents($filename);
        $requests = $content ? json_decode($content, true) : [];
        
        if (!is_array($requests)) {
            return [];
        }
        
        // فیلتر کردن درخواست‌های قدیمی
        $cutoff = time() - $window;
        return array_filter($requests, function($timestamp) use ($cutoff) {
            return $timestamp > $cutoff;
        });
    }
    
    /**
     * ثبت درخواست جدید
     */
    private function recordRequest(string $ip): void
    {
        $filename = $this->getStorageFile($ip);
        $requests = $this->getRequests($ip, 3600);
        
        $requests[] = time();
        
        // نگهداری فقط 200 درخواست اخیر
        if (count($requests) > 200) {
            $requests = array_slice($requests, -200);
        }
        
        file_put_contents($filename, json_encode($requests), LOCK_EX);
    }
    
    /**
     * دریافت نام فایل ذخیره‌سازی
     */
    private function getStorageFile(string $ip): string
    {
        $hash = md5($ip);
        return $this->storageDir . $hash . '.json';
    }
    
    /**
     * پاک‌سازی فایل‌های قدیمی
     */
    public function cleanup(): void
    {
        $files = glob($this->storageDir . '*.json');
        $cutoff = time() - 7200; // 2 ساعت
        
        foreach ($files as $file) {
            if (filemtime($file) < $cutoff) {
                unlink($file);
            }
        }
    }
    
    /**
     * دریافت IP کلاینت
     */
    private function getClientIP(): string
    {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                return $ip;
            }
        }
        
        return 'unknown';
    }
    
    /**
     * پاسخ درخواست بیش از حد
     */
    private function tooManyRequests(): void
    {
        http_response_code(429);
        header('Content-Type: application/json; charset=UTF-8');
        header('Retry-After: 3600'); // تلاش مجدد بعد از 1 ساعت
        
        echo json_encode([
            'success' => false,
            'message' => 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً بعداً تلاش کنید.',
            'error' => 'too_many_requests',
            'retry_after' => 3600
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        
        exit;
    }
}
