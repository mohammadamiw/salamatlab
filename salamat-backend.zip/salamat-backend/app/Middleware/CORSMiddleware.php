<?php

/**
 * CORS Middleware
 * 
 * مدیریت Cross-Origin Resource Sharing
 */

class CORSMiddleware
{
    private $config;
    
    public function __construct()
    {
        $this->config = require __DIR__ . '/../../config/app.php';
    }
    
    /**
     * اجرای middleware
     */
    public function handle(): void
    {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $allowedOrigins = $this->config['security']['allowed_origins'] ?? ['*'];
        
        // بررسی origin های مجاز
        if ($this->isOriginAllowed($origin, $allowedOrigins)) {
            header("Access-Control-Allow-Origin: $origin");
        } elseif (in_array('*', $allowedOrigins)) {
            header("Access-Control-Allow-Origin: *");
        }
        
        // تنظیم سایر هدرهای CORS
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, PATCH');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-API-Key, Accept, Origin');
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400'); // 24 ساعت
        
        // پاسخ به درخواست OPTIONS (preflight)
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }
    
    /**
     * بررسی مجاز بودن origin
     */
    private function isOriginAllowed(string $origin, array $allowedOrigins): bool
    {
        if (empty($origin)) {
            return false;
        }
        
        // اجازه همیشه برای origin های local در محیط توسعه
        if ($this->config['environment'] === 'development') {
            $localPatterns = [
                '/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/',
                '/^https?:\/\/192\.168\.\d+\.\d+(:\d+)?$/',
                '/^https?:\/\/10\.\d+\.\d+\.\d+(:\d+)?$/'
            ];
            
            foreach ($localPatterns as $pattern) {
                if (preg_match($pattern, $origin)) {
                    return true;
                }
            }
        }
        
        return in_array($origin, $allowedOrigins);
    }
}
