<?php

/**
 * Authentication Middleware
 * 
 * بررسی احراز هویت کاربران
 */

class AuthMiddleware
{
    private $config;
    private $db;
    
    public function __construct()
    {
        $this->config = require __DIR__ . '/../../config/app.php';
        $this->db = Database::getInstance();
    }
    
    /**
     * اجرای middleware
     */
    public function handle(): void
    {
        $token = $this->getAuthToken();
        
        if (!$token) {
            $this->unauthorized('توکن احراز هویت ارائه نشده است');
        }
        
        $user = $this->validateToken($token);
        
        if (!$user) {
            $this->unauthorized('توکن احراز هویت نامعتبر است');
        }
        
        // تنظیم کاربر برای استفاده در کنترلرها
        $_SESSION['auth_user'] = $user;
        $_SESSION['auth_user_id'] = $user['id'];
    }
    
    /**
     * دریافت توکن از header
     */
    private function getAuthToken(): ?string
    {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return $matches[1];
        }
        
        return null;
    }
    
    /**
     * اعتبارسنجی توکن JWT
     */
    private function validateToken(string $token): ?array
    {
        try {
            // تجزیه توکن JWT
            $parts = explode('.', $token);
            
            if (count($parts) !== 3) {
                return null;
            }
            
            [$headerEncoded, $payloadEncoded, $signatureEncoded] = $parts;
            
            // بررسی امضا
            $signature = base64_decode($signatureEncoded);
            $expectedSignature = hash_hmac(
                'sha256', 
                $headerEncoded . '.' . $payloadEncoded, 
                $this->config['security']['jwt_secret'], 
                true
            );
            
            if (!hash_equals($expectedSignature, $signature)) {
                return null;
            }
            
            // تجزیه payload
            $payload = json_decode(base64_decode($payloadEncoded), true);
            
            if (!$payload || !isset($payload['user_id']) || !isset($payload['exp'])) {
                return null;
            }
            
            // بررسی انقضا
            if (time() > $payload['exp']) {
                return null;
            }
            
            // دریافت کاربر از دیتابیس
            $user = $this->db->fetch(
                "SELECT id, phone, email, first_name, last_name, is_active, is_verified, is_profile_complete 
                 FROM users WHERE id = ? AND is_active = 1",
                [$payload['user_id']]
            );
            
            return $user ?: null;
            
        } catch (Exception $e) {
            error_log("Token validation error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * ارسال پاسخ غیرمجاز
     */
    private function unauthorized(string $message): void
    {
        http_response_code(401);
        header('Content-Type: application/json; charset=UTF-8');
        
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error' => 'unauthorized'
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        
        exit;
    }
    
    /**
     * تولید توکن JWT
     */
    public static function generateToken(array $user): string
    {
        $config = require __DIR__ . '/../../config/app.php';
        
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode([
            'user_id' => $user['id'],
            'phone' => $user['phone'],
            'iat' => time(),
            'exp' => time() + $config['security']['jwt_expire']
        ]);
        
        $headerEncoded = rtrim(strtr(base64_encode($header), '+/', '-_'), '=');
        $payloadEncoded = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
        
        $signature = hash_hmac(
            'sha256',
            $headerEncoded . '.' . $payloadEncoded,
            $config['security']['jwt_secret'],
            true
        );
        
        $signatureEncoded = rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');
        
        return $headerEncoded . '.' . $payloadEncoded . '.' . $signatureEncoded;
    }
}
