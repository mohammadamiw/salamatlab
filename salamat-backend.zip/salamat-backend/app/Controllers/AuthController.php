<?php

namespace App\Controllers;

use App\Models\User;
use App\Services\OTPService;
use App\Services\SMSService;
use Exception;

class AuthController extends BaseController
{
    private $otpService;
    private $smsService;
    private $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->otpService = new OTPService();
        $this->smsService = new SMSService();
        $this->userModel = new User();
    }

    /**
     * ارسال کد OTP به شماره موبایل
     */
    public function sendOTP()
    {
        try {
            $phone = $this->getInput('phone');
            
            if (!$phone || !$this->validatePhone($phone)) {
                return $this->error('شماره موبایل معتبر نیست', 400);
            }

            // بررسی وجود کاربر
            $user = $this->userModel->findByPhone($phone);
            
            // تولید کد OTP
            $otpCode = $this->otpService->generateOTP();
            
            // ذخیره کد OTP
            $this->otpService->storeOTP($phone, $otpCode);
            
            // ارسال پیامک
            $message = "کد تایید شما: {$otpCode}\nسامانه سلامت‌لاب";
            $smsResult = $this->smsService->sendSMS($phone, $message);
            
            if (!$smsResult['success']) {
                return $this->error('خطا در ارسال پیامک: ' . $smsResult['message'], 500);
            }

            return $this->success([
                'message' => 'کد تایید ارسال شد',
                'phone' => $phone,
                'user_exists' => $user ? true : false
            ]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * تایید کد OTP و ورود کاربر
     */
    public function verifyOTP()
    {
        try {
            $phone = $this->getInput('phone');
            $otpCode = $this->getInput('otp');
            
            if (!$phone || !$otpCode) {
                return $this->error('شماره موبایل و کد تایید الزامی است', 400);
            }

            // تایید کد OTP
            $isValid = $this->otpService->verifyOTP($phone, $otpCode);
            
            if (!$isValid) {
                return $this->error('کد تایید نامعتبر یا منقضی شده است', 400);
            }

            // پیدا کردن یا ایجاد کاربر
            $user = $this->userModel->findByPhone($phone);
            
            if (!$user) {
                // ایجاد کاربر جدید
                $userData = [
                    'phone' => $phone,
                    'status' => 'active',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $userId = $this->userModel->create($userData);
                $user = $this->userModel->find($userId);
            }

            // تولید JWT Token
            $token = $this->generateJWT($user);
            
            // حذف کد OTP استفاده شده
            $this->otpService->deleteOTP($phone);

            return $this->success([
                'message' => 'ورود موفقیت‌آمیز',
                'user' => $this->sanitizeUser($user),
                'token' => $token,
                'is_new_user' => !$user['profile_completed']
            ]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * تکمیل پروفایل کاربر
     */
    public function completeProfile()
    {
        try {
            $user = $this->getCurrentUser();
            
            if (!$user) {
                return $this->error('کاربر احراز هویت نشده است', 401);
            }

            $data = [
                'first_name' => $this->getInput('first_name'),
                'last_name' => $this->getInput('last_name'),
                'national_id' => $this->getInput('national_id'),
                'birth_date' => $this->getInput('birth_date'),
                'gender' => $this->getInput('gender'),
                'profile_completed' => 1,
                'updated_at' => date('Y-m-d H:i:s')
            ];

            // اعتبارسنجی داده‌ها
            $validation = $this->validateProfileData($data);
            if (!$validation['valid']) {
                return $this->error($validation['message'], 400);
            }

            // به‌روزرسانی کاربر
            $this->userModel->update($user['id'], $data);
            
            // دریافت کاربر به‌روزرسانی شده
            $updatedUser = $this->userModel->find($user['id']);

            return $this->success([
                'message' => 'پروفایل با موفقیت تکمیل شد',
                'user' => $this->sanitizeUser($updatedUser)
            ]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * خروج کاربر
     */
    public function logout()
    {
        try {
            // در JWT، خروج با حذف token از سمت کلاینت انجام می‌شود
            // اینجا می‌توانیم token را blacklist کنیم
            
            return $this->success(['message' => 'خروج موفقیت‌آمیز']);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت اطلاعات کاربر فعلی
     */
    public function me()
    {
        try {
            $user = $this->getCurrentUser();
            
            if (!$user) {
                return $this->error('کاربر احراز هویت نشده است', 401);
            }

            return $this->success([
                'user' => $this->sanitizeUser($user)
            ]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * اعتبارسنجی شماره موبایل
     */
    private function validatePhone($phone)
    {
        // حذف کاراکترهای غیرعددی
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        // بررسی فرمت شماره موبایل ایرانی
        if (preg_match('/^09[0-9]{9}$/', $phone)) {
            return true;
        }
        
        // بررسی فرمت بین‌المللی
        if (preg_match('/^\+989[0-9]{9}$/', $phone)) {
            return true;
        }
        
        return false;
    }

    /**
     * اعتبارسنجی داده‌های پروفایل
     */
    private function validateProfileData($data)
    {
        if (empty($data['first_name'])) {
            return ['valid' => false, 'message' => 'نام الزامی است'];
        }
        
        if (empty($data['last_name'])) {
            return ['valid' => false, 'message' => 'نام خانوادگی الزامی است'];
        }
        
        if (!empty($data['national_id']) && !$this->validateNationalId($data['national_id'])) {
            return ['valid' => false, 'message' => 'کد ملی نامعتبر است'];
        }
        
        if (!empty($data['birth_date']) && !$this->validateDate($data['birth_date'])) {
            return ['valid' => false, 'message' => 'تاریخ تولد نامعتبر است'];
        }
        
        if (!empty($data['gender']) && !in_array($data['gender'], ['male', 'female'])) {
            return ['valid' => false, 'message' => 'جنسیت نامعتبر است'];
        }
        
        return ['valid' => true];
    }

    /**
     * اعتبارسنجی کد ملی
     */
    private function validateNationalId($nationalId)
    {
        if (strlen($nationalId) !== 10) {
            return false;
        }
        
        $sum = 0;
        for ($i = 0; $i < 9; $i++) {
            $sum += $nationalId[$i] * (10 - $i);
        }
        
        $remainder = $sum % 11;
        $checkDigit = $remainder < 2 ? $remainder : 11 - $remainder;
        
        return $checkDigit == $nationalId[9];
    }

    /**
     * اعتبارسنجی تاریخ
     */
    private function validateDate($date)
    {
        $d = \DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    /**
     * تولید JWT Token
     */
    private function generateJWT($user)
    {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode([
            'user_id' => $user['id'],
            'phone' => $user['phone'],
            'iat' => time(),
            'exp' => time() + (24 * 60 * 60) // 24 ساعت
        ]);
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $_ENV['JWT_SECRET'] ?? 'default_secret', true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }

    /**
     * پاک‌سازی اطلاعات کاربر برای ارسال
     */
    private function sanitizeUser($user)
    {
        unset($user['password']);
        unset($user['otp_code']);
        unset($user['otp_expires_at']);
        return $user;
    }
}
