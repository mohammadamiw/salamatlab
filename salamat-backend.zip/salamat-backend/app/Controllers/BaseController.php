<?php

/**
 * کنترلر پایه
 * Base Controller Class
 * 
 * ارائه قابلیت‌های مشترک برای همه کنترلرها
 */

abstract class BaseController
{
    protected $db;
    protected $config;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->config = require __DIR__ . '/../../config/app.php';
    }
    
    /**
     * ارسال پاسخ موفق JSON
     */
    protected function success($data = null, string $message = 'موفق', int $statusCode = 200): void
    {
        $this->jsonResponse([
            'success' => true,
            'message' => $message,
            'data' => $data
        ], $statusCode);
    }
    
    /**
     * ارسال پاسخ خطا JSON
     */
    protected function error(string $message, int $statusCode = 400, $errors = null): void
    {
        $response = [
            'success' => false,
            'message' => $message
        ];
        
        if ($errors !== null) {
            $response['errors'] = $errors;
        }
        
        $this->jsonResponse($response, $statusCode);
    }
    
    /**
     * ارسال پاسخ JSON
     */
    protected function jsonResponse(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * دریافت داده‌های JSON از درخواست
     */
    protected function getJsonInput(): array
    {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->error('داده‌های JSON نامعتبر', 400);
        }
        
        return $data ?: [];
    }
    
    /**
     * دریافت داده‌های GET
     */
    protected function getQueryParams(): array
    {
        return $_GET;
    }
    
    /**
     * دریافت داده‌های POST
     */
    protected function getPostData(): array
    {
        return $_POST;
    }
    
    /**
     * دریافت پارامتر از URL
     */
    protected function getUrlParam(string $key, $default = null)
    {
        return $_GET[$key] ?? $default;
    }
    
    /**
     * دریافت هدر
     */
    protected function getHeader(string $name): ?string
    {
        $headers = getallheaders();
        
        // Case-insensitive header search
        foreach ($headers as $key => $value) {
            if (strtolower($key) === strtolower($name)) {
                return $value;
            }
        }
        
        return null;
    }
    
    /**
     * دریافت توکن Authorization
     */
    protected function getAuthToken(): ?string
    {
        $authHeader = $this->getHeader('Authorization');
        
        if ($authHeader && strpos($authHeader, 'Bearer ') === 0) {
            return substr($authHeader, 7);
        }
        
        return null;
    }
    
    /**
     * اعتبارسنجی داده‌های ورودی
     */
    protected function validate(array $data, array $rules): void
    {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            $ruleItems = explode('|', $rule);
            
            foreach ($ruleItems as $ruleItem) {
                $error = $this->validateRule($field, $value, $ruleItem);
                if ($error) {
                    $errors[$field] = $error;
                    break; // توقف در اولین خطا
                }
            }
        }
        
        if (!empty($errors)) {
            $this->error('داده‌های ورودی نامعتبر', 422, $errors);
        }
    }
    
    /**
     * اعتبارسنجی یک قانون
     */
    private function validateRule(string $field, $value, string $rule): ?string
    {
        // Required
        if ($rule === 'required' && (is_null($value) || $value === '')) {
            return "فیلد {$field} الزامی است";
        }
        
        // Skip other validations if value is empty and not required
        if (is_null($value) || $value === '') {
            return null;
        }
        
        // Email
        if ($rule === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            return "فیلد {$field} باید ایمیل معتبر باشد";
        }
        
        // Phone
        if ($rule === 'phone' && !preg_match('/^09\d{9}$/', $value)) {
            return "فیلد {$field} باید شماره موبایل معتبر باشد (۰۹XXXXXXXXX)";
        }
        
        // National ID
        if ($rule === 'national_id' && !$this->validateNationalId($value)) {
            return "فیلد {$field} باید کد ملی معتبر باشد";
        }
        
        // Min length
        if (preg_match('/^min:(\d+)$/', $rule, $matches)) {
            $minLength = (int)$matches[1];
            if (strlen($value) < $minLength) {
                return "فیلد {$field} باید حداقل {$minLength} کاراکتر باشد";
            }
        }
        
        // Max length
        if (preg_match('/^max:(\d+)$/', $rule, $matches)) {
            $maxLength = (int)$matches[1];
            if (strlen($value) > $maxLength) {
                return "فیلد {$field} باید حداکثر {$maxLength} کاراکتر باشد";
            }
        }
        
        // In array
        if (preg_match('/^in:(.+)$/', $rule, $matches)) {
            $allowedValues = explode(',', $matches[1]);
            if (!in_array($value, $allowedValues)) {
                return "فیلد {$field} باید یکی از مقادیر مجاز باشد";
            }
        }
        
        // Numeric
        if ($rule === 'numeric' && !is_numeric($value)) {
            return "فیلد {$field} باید عدد باشد";
        }
        
        // Date
        if ($rule === 'date' && !$this->validateDate($value)) {
            return "فیلد {$field} باید تاریخ معتبر باشد";
        }
        
        return null;
    }
    
    /**
     * اعتبارسنجی کد ملی
     */
    private function validateNationalId(string $nationalId): bool
    {
        if (strlen($nationalId) !== 10 || !ctype_digit($nationalId)) {
            return false;
        }
        
        $check = 0;
        for ($i = 0; $i < 9; $i++) {
            $check += ((10 - $i) * (int)$nationalId[$i]);
        }
        
        $mod = $check % 11;
        $expectedCheck = $mod < 2 ? $mod : 11 - $mod;
        
        return $expectedCheck === (int)$nationalId[9];
    }
    
    /**
     * اعتبارسنجی تاریخ
     */
    private function validateDate(string $date): bool
    {
        $formats = ['Y-m-d', 'Y-m-d H:i:s', 'Y/m/d', 'Y/m/d H:i:s'];
        
        foreach ($formats as $format) {
            $dateTime = DateTime::createFromFormat($format, $date);
            if ($dateTime && $dateTime->format($format) === $date) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * صفحه‌بندی داده‌ها
     */
    protected function paginate(array $data, int $total, int $page = 1, int $perPage = 15): array
    {
        $totalPages = ceil($total / $perPage);
        
        return [
            'data' => $data,
            'pagination' => [
                'currentPage' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'totalPages' => $totalPages,
                'hasNextPage' => $page < $totalPages,
                'hasPrevPage' => $page > 1
            ]
        ];
    }
    
    /**
     * لاگ کردن خطا
     */
    protected function logError(string $message, array $context = []): void
    {
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => 'ERROR',
            'message' => $message,
            'context' => $context,
            'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
            'request_method' => $_SERVER['REQUEST_METHOD'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'ip' => $this->getClientIP()
        ];
        
        $logLine = json_encode($logData, JSON_UNESCAPED_UNICODE) . "\n";
        $logFile = __DIR__ . '/../../storage/logs/error-' . date('Y-m-d') . '.log';
        
        // اطمینان از وجود پوشه logs
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * لاگ کردن اطلاعات
     */
    protected function logInfo(string $message, array $context = []): void
    {
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => 'INFO',
            'message' => $message,
            'context' => $context
        ];
        
        $logLine = json_encode($logData, JSON_UNESCAPED_UNICODE) . "\n";
        $logFile = __DIR__ . '/../../storage/logs/info-' . date('Y-m-d') . '.log';
        
        // اطمینان از وجود پوشه logs
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * دریافت IP کلاینت
     */
    protected function getClientIP(): string
    {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                return $ip;
            }
        }
        
        return 'unknown';
    }
    
    /**
     * بررسی نوع درخواست
     */
    protected function isPost(): bool
    {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }
    
    protected function isGet(): bool
    {
        return $_SERVER['REQUEST_METHOD'] === 'GET';
    }
    
    protected function isPut(): bool
    {
        return $_SERVER['REQUEST_METHOD'] === 'PUT';
    }
    
    protected function isDelete(): bool
    {
        return $_SERVER['REQUEST_METHOD'] === 'DELETE';
    }
    
    /**
     * بررسی درخواست AJAX
     */
    protected function isAjax(): bool
    {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}
