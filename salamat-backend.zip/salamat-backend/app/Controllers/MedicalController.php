<?php

namespace App\Controllers;

use App\Models\Doctor;
use App\Models\MedicalService;
use App\Models\CheckupRequest;
use App\Models\HomeSamplingRequest;
use Exception;

class MedicalController extends BaseController
{
    private $doctorModel;
    private $medicalServiceModel;
    private $checkupRequestModel;
    private $homeSamplingRequestModel;

    public function __construct()
    {
        parent::__construct();
        $this->doctorModel = new Doctor();
        $this->medicalServiceModel = new MedicalService();
        $this->checkupRequestModel = new CheckupRequest();
        $this->homeSamplingRequestModel = new HomeSamplingRequest();
    }

    /**
     * دریافت لیست پزشکان
     */
    public function getDoctors()
    {
        try {
            $specialty = $this->getInput('specialty');
            $search = $this->getInput('search');
            $page = (int)($this->getInput('page') ?? 1);
            $limit = (int)($this->getInput('limit') ?? 10);
            
            $filters = [];
            if ($specialty) {
                $filters['specialty'] = $specialty;
            }
            if ($search) {
                $filters['search'] = $search;
            }
            
            $doctors = $this->doctorModel->getAll($filters, $page, $limit);
            $total = $this->doctorModel->count($filters);
            
            return $this->success([
                'doctors' => $doctors,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $limit,
                    'total' => $total,
                    'total_pages' => ceil($total / $limit)
                ]
            ]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت اطلاعات یک پزشک
     */
    public function getDoctor()
    {
        try {
            $id = $this->getInput('id');
            
            if (!$id) {
                return $this->error('شناسه پزشک الزامی است', 400);
            }
            
            $doctor = $this->doctorModel->find($id);
            
            if (!$doctor) {
                return $this->error('پزشک یافت نشد', 404);
            }
            
            return $this->success(['doctor' => $doctor]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت لیست تخصص‌ها
     */
    public function getSpecialties()
    {
        try {
            $specialties = $this->doctorModel->getSpecialties();
            
            return $this->success(['specialties' => $specialties]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت لیست خدمات پزشکی
     */
    public function getMedicalServices()
    {
        try {
            $category = $this->getInput('category');
            $search = $this->getInput('search');
            $page = (int)($this->getInput('page') ?? 1);
            $limit = (int)($this->getInput('limit') ?? 10);
            
            $filters = [];
            if ($category) {
                $filters['category'] = $category;
            }
            if ($search) {
                $filters['search'] = $search;
            }
            
            $services = $this->medicalServiceModel->getAll($filters, $page, $limit);
            $total = $this->medicalServiceModel->count($filters);
            
            return $this->success([
                'services' => $services,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $limit,
                    'total' => $total,
                    'total_pages' => ceil($total / $limit)
                ]
            ]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت اطلاعات یک خدمت پزشکی
     */
    public function getMedicalService()
    {
        try {
            $id = $this->getInput('id');
            
            if (!$id) {
                return $this->error('شناسه خدمت الزامی است', 400);
            }
            
            $service = $this->medicalServiceModel->find($id);
            
            if (!$service) {
                return $this->error('خدمت یافت نشد', 404);
            }
            
            return $this->success(['service' => $service]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت دسته‌بندی خدمات
     */
    public function getServiceCategories()
    {
        try {
            $categories = $this->medicalServiceModel->getCategories();
            
            return $this->success(['categories' => $categories]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * ثبت درخواست ویزیت
     */
    public function createCheckupRequest()
    {
        try {
            $user = $this->getCurrentUser();
            
            if (!$user) {
                return $this->error('کاربر احراز هویت نشده است', 401);
            }
            
            $data = [
                'user_id' => $user['id'],
                'doctor_id' => $this->getInput('doctor_id'),
                'service_id' => $this->getInput('service_id'),
                'preferred_date' => $this->getInput('preferred_date'),
                'preferred_time' => $this->getInput('preferred_time'),
                'symptoms' => $this->getInput('symptoms'),
                'notes' => $this->getInput('notes'),
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // اعتبارسنجی داده‌ها
            $validation = $this->validateCheckupRequest($data);
            if (!$validation['valid']) {
                return $this->error($validation['message'], 400);
            }
            
            // بررسی وجود پزشک
            $doctor = $this->doctorModel->find($data['doctor_id']);
            if (!$doctor) {
                return $this->error('پزشک یافت نشد', 404);
            }
            
            // بررسی وجود خدمت
            $service = $this->medicalServiceModel->find($data['service_id']);
            if (!$service) {
                return $this->error('خدمت یافت نشد', 404);
            }
            
            // ایجاد درخواست
            $requestId = $this->checkupRequestModel->create($data);
            $request = $this->checkupRequestModel->find($requestId);
            
            return $this->success([
                'message' => 'درخواست ویزیت با موفقیت ثبت شد',
                'request' => $request
            ], 201);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * ثبت درخواست نمونه‌گیری در منزل
     */
    public function createHomeSamplingRequest()
    {
        try {
            $user = $this->getCurrentUser();
            
            if (!$user) {
                return $this->error('کاربر احراز هویت نشده است', 401);
            }
            
            $data = [
                'user_id' => $user['id'],
                'service_id' => $this->getInput('service_id'),
                'preferred_date' => $this->getInput('preferred_date'),
                'preferred_time' => $this->getInput('preferred_time'),
                'address' => $this->getInput('address'),
                'phone' => $this->getInput('phone'),
                'notes' => $this->getInput('notes'),
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // اعتبارسنجی داده‌ها
            $validation = $this->validateHomeSamplingRequest($data);
            if (!$validation['valid']) {
                return $this->error($validation['message'], 400);
            }
            
            // بررسی وجود خدمت
            $service = $this->medicalServiceModel->find($data['service_id']);
            if (!$service) {
                return $this->error('خدمت یافت نشد', 404);
            }
            
            // ایجاد درخواست
            $requestId = $this->homeSamplingRequestModel->create($data);
            $request = $this->homeSamplingRequestModel->find($requestId);
            
            return $this->success([
                'message' => 'درخواست نمونه‌گیری با موفقیت ثبت شد',
                'request' => $request
            ], 201);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت درخواست‌های کاربر
     */
    public function getUserRequests()
    {
        try {
            $user = $this->getCurrentUser();
            
            if (!$user) {
                return $this->error('کاربر احراز هویت نشده است', 401);
            }
            
            $type = $this->getInput('type'); // 'checkup' یا 'sampling'
            $page = (int)($this->getInput('page') ?? 1);
            $limit = (int)($this->getInput('limit') ?? 10);
            
            $requests = [];
            
            if (!$type || $type === 'checkup') {
                $checkupRequests = $this->checkupRequestModel->getByUserId($user['id'], $page, $limit);
                foreach ($checkupRequests as $request) {
                    $request['type'] = 'checkup';
                    $requests[] = $request;
                }
            }
            
            if (!$type || $type === 'sampling') {
                $samplingRequests = $this->homeSamplingRequestModel->getByUserId($user['id'], $page, $limit);
                foreach ($samplingRequests as $request) {
                    $request['type'] = 'sampling';
                    $requests[] = $request;
                }
            }
            
            // مرتب‌سازی بر اساس تاریخ ایجاد
            usort($requests, function($a, $b) {
                return strtotime($b['created_at']) - strtotime($a['created_at']);
            });
            
            return $this->success(['requests' => $requests]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * لغو درخواست
     */
    public function cancelRequest()
    {
        try {
            $user = $this->getCurrentUser();
            
            if (!$user) {
                return $this->error('کاربر احراز هویت نشده است', 401);
            }
            
            $requestId = $this->getInput('request_id');
            $type = $this->getInput('type'); // 'checkup' یا 'sampling'
            
            if (!$requestId || !$type) {
                return $this->error('شناسه درخواست و نوع الزامی است', 400);
            }
            
            $model = $type === 'checkup' ? $this->checkupRequestModel : $this->homeSamplingRequestModel;
            $request = $model->find($requestId);
            
            if (!$request) {
                return $this->error('درخواست یافت نشد', 404);
            }
            
            if ($request['user_id'] !== $user['id']) {
                return $this->error('شما مجاز به لغو این درخواست نیستید', 403);
            }
            
            if ($request['status'] !== 'pending') {
                return $this->error('فقط درخواست‌های در انتظار قابل لغو هستند', 400);
            }
            
            // به‌روزرسانی وضعیت
            $model->update($requestId, [
                'status' => 'cancelled',
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            
            return $this->success(['message' => 'درخواست با موفقیت لغو شد']);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * اعتبارسنجی درخواست ویزیت
     */
    private function validateCheckupRequest($data)
    {
        if (empty($data['doctor_id'])) {
            return ['valid' => false, 'message' => 'انتخاب پزشک الزامی است'];
        }
        
        if (empty($data['service_id'])) {
            return ['valid' => false, 'message' => 'انتخاب خدمت الزامی است'];
        }
        
        if (empty($data['preferred_date'])) {
            return ['valid' => false, 'message' => 'تاریخ مورد نظر الزامی است'];
        }
        
        if (!$this->validateDate($data['preferred_date'])) {
            return ['valid' => false, 'message' => 'تاریخ نامعتبر است'];
        }
        
        if (strtotime($data['preferred_date']) < strtotime('today')) {
            return ['valid' => false, 'message' => 'تاریخ نمی‌تواند در گذشته باشد'];
        }
        
        return ['valid' => true];
    }

    /**
     * اعتبارسنجی درخواست نمونه‌گیری
     */
    private function validateHomeSamplingRequest($data)
    {
        if (empty($data['service_id'])) {
            return ['valid' => false, 'message' => 'انتخاب خدمت الزامی است'];
        }
        
        if (empty($data['preferred_date'])) {
            return ['valid' => false, 'message' => 'تاریخ مورد نظر الزامی است'];
        }
        
        if (!$this->validateDate($data['preferred_date'])) {
            return ['valid' => false, 'message' => 'تاریخ نامعتبر است'];
        }
        
        if (strtotime($data['preferred_date']) < strtotime('today')) {
            return ['valid' => false, 'message' => 'تاریخ نمی‌تواند در گذشته باشد'];
        }
        
        if (empty($data['address'])) {
            return ['valid' => false, 'message' => 'آدرس الزامی است'];
        }
        
        if (empty($data['phone'])) {
            return ['valid' => false, 'message' => 'شماره تماس الزامی است'];
        }
        
        return ['valid' => true];
    }

    /**
     * اعتبارسنجی تاریخ
     */
    private function validateDate($date)
    {
        $d = \DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }
}
