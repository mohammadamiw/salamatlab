<?php

namespace App\Controllers;

use App\Models\BlogPost;
use App\Models\ContactMessage;
use App\Models\FeedbackSurvey;
use Exception;

class ContentController extends BaseController
{
    private $blogPostModel;
    private $contactMessageModel;
    private $feedbackSurveyModel;

    public function __construct()
    {
        parent::__construct();
        $this->blogPostModel = new BlogPost();
        $this->contactMessageModel = new ContactMessage();
        $this->feedbackSurveyModel = new FeedbackSurvey();
    }

    /**
     * دریافت لیست مقالات بلاگ
     */
    public function getBlogPosts()
    {
        try {
            $category = $this->getInput('category');
            $search = $this->getInput('search');
            $page = (int)($this->getInput('page') ?? 1);
            $limit = (int)($this->getInput('limit') ?? 10);
            
            $filters = [];
            if ($category) {
                $filters['category'] = $category;
            }
            if ($search) {
                $filters['search'] = $search;
            }
            
            $posts = $this->blogPostModel->getAll($filters, $page, $limit);
            $total = $this->blogPostModel->count($filters);
            
            return $this->success([
                'posts' => $posts,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $limit,
                    'total' => $total,
                    'total_pages' => ceil($total / $limit)
                ]
            ]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت یک مقاله بلاگ
     */
    public function getBlogPost()
    {
        try {
            $slug = $this->getInput('slug');
            
            if (!$slug) {
                return $this->error('شناسه مقاله الزامی است', 400);
            }
            
            $post = $this->blogPostModel->findBySlug($slug);
            
            if (!$post) {
                return $this->error('مقاله یافت نشد', 404);
            }
            
            // افزایش تعداد بازدید
            $this->blogPostModel->incrementViews($post['id']);
            
            return $this->success(['post' => $post]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت دسته‌بندی‌های بلاگ
     */
    public function getBlogCategories()
    {
        try {
            $categories = $this->blogPostModel->getCategories();
            
            return $this->success(['categories' => $categories]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت مقالات محبوب
     */
    public function getPopularPosts()
    {
        try {
            $limit = (int)($this->getInput('limit') ?? 5);
            $posts = $this->blogPostModel->getPopular($limit);
            
            return $this->success(['posts' => $posts]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * ارسال پیام تماس
     */
    public function sendContactMessage()
    {
        try {
            $data = [
                'name' => $this->getInput('name'),
                'email' => $this->getInput('email'),
                'phone' => $this->getInput('phone'),
                'subject' => $this->getInput('subject'),
                'message' => $this->getInput('message'),
                'status' => 'new',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // اعتبارسنجی داده‌ها
            $validation = $this->validateContactMessage($data);
            if (!$validation['valid']) {
                return $this->error($validation['message'], 400);
            }
            
            // ایجاد پیام
            $messageId = $this->contactMessageModel->create($data);
            $message = $this->contactMessageModel->find($messageId);
            
            return $this->success([
                'message' => 'پیام شما با موفقیت ارسال شد',
                'contact_message' => $message
            ], 201);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * ارسال نظرسنجی
     */
    public function submitFeedback()
    {
        try {
            $user = $this->getCurrentUser();
            
            $data = [
                'user_id' => $user ? $user['id'] : null,
                'name' => $this->getInput('name'),
                'email' => $this->getInput('email'),
                'phone' => $this->getInput('phone'),
                'service_type' => $this->getInput('service_type'),
                'rating' => $this->getInput('rating'),
                'feedback' => $this->getInput('feedback'),
                'suggestions' => $this->getInput('suggestions'),
                'status' => 'new',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // اعتبارسنجی داده‌ها
            $validation = $this->validateFeedback($data);
            if (!$validation['valid']) {
                return $this->error($validation['message'], 400);
            }
            
            // ایجاد نظرسنجی
            $feedbackId = $this->feedbackSurveyModel->create($data);
            $feedback = $this->feedbackSurveyModel->find($feedbackId);
            
            return $this->success([
                'message' => 'نظرسنجی شما با موفقیت ثبت شد',
                'feedback' => $feedback
            ], 201);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * دریافت آمار کلی
     */
    public function getStats()
    {
        try {
            $stats = [
                'total_posts' => $this->blogPostModel->count(),
                'total_contacts' => $this->contactMessageModel->count(),
                'total_feedbacks' => $this->feedbackSurveyModel->count(),
                'average_rating' => $this->feedbackSurveyModel->getAverageRating()
            ];
            
            return $this->success(['stats' => $stats]);

        } catch (Exception $e) {
            return $this->error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }

    /**
     * اعتبارسنجی پیام تماس
     */
    private function validateContactMessage($data)
    {
        if (empty($data['name'])) {
            return ['valid' => false, 'message' => 'نام الزامی است'];
        }
        
        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['valid' => false, 'message' => 'ایمیل معتبر الزامی است'];
        }
        
        if (empty($data['subject'])) {
            return ['valid' => false, 'message' => 'موضوع الزامی است'];
        }
        
        if (empty($data['message'])) {
            return ['valid' => false, 'message' => 'پیام الزامی است'];
        }
        
        return ['valid' => true];
    }

    /**
     * اعتبارسنجی نظرسنجی
     */
    private function validateFeedback($data)
    {
        if (empty($data['name'])) {
            return ['valid' => false, 'message' => 'نام الزامی است'];
        }
        
        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['valid' => false, 'message' => 'ایمیل معتبر الزامی است'];
        }
        
        if (empty($data['service_type'])) {
            return ['valid' => false, 'message' => 'نوع خدمت الزامی است'];
        }
        
        if (empty($data['rating']) || !in_array($data['rating'], [1, 2, 3, 4, 5])) {
            return ['valid' => false, 'message' => 'امتیاز الزامی است (1-5)'];
        }
        
        if (empty($data['feedback'])) {
            return ['valid' => false, 'message' => 'نظر الزامی است'];
        }
        
        return ['valid' => true];
    }
}
