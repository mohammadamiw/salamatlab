<?php
/**
 * تنظیمات اصلی آزمایشگاه سلامت
 * SalamatLab Main Configuration
 * 
 * Version: 2.0
 */

return [
    // اطلاعات اصلی برنامه
    'name' => $_ENV['APP_NAME'] ?? 'آزمایشگاه سلامت',
    'version' => '2.0.0',
    'debug' => $_ENV['APP_DEBUG'] ?? false,
    'environment' => $_ENV['APP_ENV'] ?? 'production',
    'url' => $_ENV['APP_URL'] ?? 'http://localhost',
    
    // تنظیمات امنیتی
    'security' => [
        'jwt_secret' => $_ENV['JWT_SECRET'] ?? '',
        'jwt_expire' => (int)($_ENV['JWT_EXPIRE'] ?? 86400), // 24 ساعت
        'otp_secret' => $_ENV['OTP_SECRET'] ?? '',
        'otp_expire' => (int)($_ENV['OTP_EXPIRE'] ?? 300), // 5 دقیقه
        'max_login_attempts' => (int)($_ENV['MAX_LOGIN_ATTEMPTS'] ?? 5),
        'rate_limit' => (int)($_ENV['RATE_LIMIT'] ?? 100), // درخواست در ساعت
        'allowed_origins' => explode(',', $_ENV['ALLOWED_ORIGINS'] ?? '*'),
        'encryption_key' => $_ENV['ENCRYPTION_KEY'] ?? '',
    ],
    
    // تنظیمات پیامک
    'sms' => [
        'provider' => $_ENV['SMS_PROVIDER'] ?? 'smsir',
        'api_key' => $_ENV['SMS_API_KEY'] ?? '',
        'api_url' => $_ENV['SMS_API_URL'] ?? 'https://api.sms.ir/v1/send/verify',
        'templates' => [
            'otp' => (int)($_ENV['SMS_OTP_TEMPLATE_ID'] ?? 0),
            'checkup_confirm' => (int)($_ENV['SMS_CHECKUP_CONFIRM_TEMPLATE_ID'] ?? 0),
            'feedback_confirm' => (int)($_ENV['SMS_FEEDBACK_CONFIRM_TEMPLATE_ID'] ?? 0),
            'staff_notify' => (int)($_ENV['SMS_STAFF_NOTIFY_TEMPLATE_ID'] ?? 0),
        ],
        'staff_mobile' => $_ENV['SMS_STAFF_MOBILE'] ?? '',
    ],
    
    // تنظیمات ایمیل
    'email' => [
        'driver' => $_ENV['MAIL_DRIVER'] ?? 'smtp',
        'host' => $_ENV['MAIL_HOST'] ?? 'localhost',
        'port' => (int)($_ENV['MAIL_PORT'] ?? 587),
        'username' => $_ENV['MAIL_USERNAME'] ?? '',
        'password' => $_ENV['MAIL_PASSWORD'] ?? '',
        'encryption' => $_ENV['MAIL_ENCRYPTION'] ?? 'tls',
        'from' => [
            'address' => $_ENV['MAIL_FROM_ADDRESS'] ?? 'noreply@salamatlab.com',
            'name' => $_ENV['MAIL_FROM_NAME'] ?? 'آزمایشگاه سلامت',
        ],
        'admin_email' => $_ENV['ADMIN_EMAIL'] ?? 'admin@salamatlab.com',
    ],
    
    // تنظیمات فایل‌ها
    'upload' => [
        'max_file_size' => (int)($_ENV['MAX_FILE_SIZE'] ?? 10485760), // 10MB
        'allowed_types' => ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'],
        'storage_path' => $_ENV['STORAGE_PATH'] ?? '/storage/uploads/',
    ],
    
    // تنظیمات لاگ
    'logging' => [
        'enabled' => $_ENV['LOG_ENABLED'] ?? true,
        'level' => $_ENV['LOG_LEVEL'] ?? 'error',
        'max_files' => (int)($_ENV['LOG_MAX_FILES'] ?? 30),
        'max_size' => $_ENV['LOG_MAX_SIZE'] ?? '10MB',
    ],
    
    // تنظیمات کش
    'cache' => [
        'driver' => $_ENV['CACHE_DRIVER'] ?? 'file',
        'ttl' => (int)($_ENV['CACHE_TTL'] ?? 3600), // 1 ساعت
        'prefix' => $_ENV['CACHE_PREFIX'] ?? 'salamat_',
    ],
    
    // تنظیمات منطقه زمانی و زبان
    'timezone' => $_ENV['TIMEZONE'] ?? 'Asia/Tehran',
    'locale' => $_ENV['LOCALE'] ?? 'fa',
    'charset' => 'UTF-8',
    
    // تنظیمات پنل ادمین
    'admin' => [
        'username' => $_ENV['ADMIN_USERNAME'] ?? 'admin',
        'password_hash' => $_ENV['ADMIN_PASSWORD_HASH'] ?? '',
        'email' => $_ENV['ADMIN_EMAIL'] ?? 'admin@salamatlab.com',
        'session_lifetime' => (int)($_ENV['ADMIN_SESSION_LIFETIME'] ?? 7200), // 2 ساعت
    ],
    
    // اطلاعات تماس
    'contact' => [
        'phone' => $_ENV['CONTACT_PHONE'] ?? '021-46833010',
        'email' => $_ENV['CONTACT_EMAIL'] ?? 'info@salamatlab.com',
        'address' => $_ENV['CONTACT_ADDRESS'] ?? 'شهرقدس، میدان مصلی، خیابان شهید بهشتی',
        'working_hours' => $_ENV['WORKING_HOURS'] ?? 'شنبه تا پنج‌شنبه: 8:00 تا 18:00',
    ],
    
    // API تنظیمات
    'api' => [
        'version' => 'v1',
        'prefix' => 'api',
        'rate_limit' => (int)($_ENV['API_RATE_LIMIT'] ?? 60), // درخواست در دقیقه
        'pagination' => [
            'default_per_page' => 15,
            'max_per_page' => 100,
        ],
    ],
];
